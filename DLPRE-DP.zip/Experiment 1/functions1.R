Sys.setlocale("LC_ALL","Chinese") # ���Ӣ��ϵͳ�µ�����

library(ggplot2)
library(ggpubr)
library(RColorBrewer)  
library(Runuran)
library(matrixStats)
library(doParallel) 
library(doSNOW)
library(foreach)
library(glmnet)
library(dfoptim)  # derivative-free optimization 
library(ggforce)
library(parallel)
library(MASS)

#global least product relative error estimator
glpre <- function(x, y, w){
  x <- as.matrix(x)
  y <- as.vector(y)
  n <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  t1 <- proc.time()
  par <- coef(lm(log(y)~x+0))
  t2 <- proc.time()
  b.est <- par+100 
  for(k in 1:1000){
    f <- tx %*% ((yinv * exp(x %*% par) - y*exp(-x %*% par))*w) 
    tt <- (yinv*exp(x %*% par)+y*exp(-x %*% par))*w 
    f_diff=tx %*% (x*c(tt)) 
    b.est <- par-solve(f_diff)%*%f
    if(norm(b.est - par,"2")<=1e-6) break
    par <- b.est
  }
  t3 <- proc.time()
  return(list(beta=b.est,ct=(t3-t1)[3]))
}

#average least product relative error estimator
alpre <- function(x, y, nmachine=2,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  w <- list()
  for (j in 1:nmachine) {
    w[[j]] <- rep(1,length(y[groups[[j]]]))
  }
  t1 <- proc.time()
  para <- sapply(1:nmachine, function(j){glpre(x[groups[[j]], ], y[groups[[j]]],w[[j]])$beta})#�õ�һ��p*k�ľ���
  t2 <- proc.time()
  b.est <- rowMeans(para)
  t3 <- proc.time()
  running.time <-(t2-t1)[3]/nmachine + (t3-t2)[3]
  return(list(beta=b.est,running_time=running.time))
}

#local estimator based on the first machine 
lpre_f <- function(x, y, nmachine=2,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  x1 <- x[groups[[1]], ]
  y1 <- y[groups[[1]]]
  tx1 <- tx[, groups[[1]]] 
  yinv1 <- yinv[groups[[1]]]
  
  ## Calculate the initial estimate for the first machine
  par <- glpre(x1, y1,1)$beta
  
  return(list(beta=par ))
}

lpre_u <- function(x, y,r,nmachine){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  t1 <- proc.time()
  index <- 1:N
  pi <- rep((r/N),N)
  decision <- rbinom(N,rep(1,N),prob=pi)
  pilot_index <- index[decision==1]
  t2 <- proc.time()
  t_p = (t2[3]-t1[3])/nmachine
  
  t.start <- proc.time()
  
  xu <- x[pilot_index, ]
  yu <- y[pilot_index]
 
  ## Calculate the initial estimate on pilot sample
  fit.glpre.u = glpre(xu,yu,1)
  beta = fit.glpre.u$beta
  t.end <- proc.time()
  
  ct <- (t.end-t.start)[3] + t_p
  
  return(list(beta=beta, ct=ct,xu=xu,yu=yu))
}

lpre_p <- function(x, y, r0, r,tau,nmachine,alpha.case){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  p <- ncol(x)
  
  if(alpha.case==1){
    alpha <- diag(rep(1,p))
  }else{
    if(alpha.case==2){
      alpha <- rep(1,p)
    }else{
      alpha <- c(1,rep(0,p-1))  
    }
  } 
  
  ## get the pilot estimator and pilot sample
  fit.lpre.u = lpre_u(x, y, r0,nmachine)
  par0 = fit.lpre.u$beta
  t_u = fit.lpre.u$ct
  xu = fit.lpre.u$xu
  yu = fit.lpre.u$yu
 
  ## Calculate the subsampling probability and get the subsample
  t1 <- proc.time()
  epsilon.u = yu*exp(-xu %*% par0)
  D <- t(xu)%*%(xu*c(epsilon.u^{-1}+epsilon.u))/length(yu)  
  phi_hat <- sum(abs(epsilon.u^{-1} -epsilon.u)* (colSums((alpha %*%solve(D) %*% t(xu))^2))^{1/2})/length(yu)
  t2 <- proc.time()
  epsilon = y*exp(-x %*% par0)
  h <- abs(epsilon^{-1} - epsilon)* (colSums((alpha %*%solve(D) %*% t(x))^2))^{1/2}
  P <- h/(N*phi_hat)
  P.new <- abs((1-tau)*P+tau/N+1/(r+1e-6))/2-abs((1-tau)*P+tau/N-1/(r+1e-6))/2
  index <- 1:N
  eta <- rbinom(N,rep(1,N),prob=r*P.new)
  sub_index <- index[eta==1]
  t3 <- proc.time()
  t_p = (t3-t2)[3]/nmachine + (t2-t1)[3]
  
  t.start <- proc.time()
  
  ## Calculate the subsample estimator
  Pi.u <- rep(1/N,length(yu))
  
  xp <- x[sub_index, ]
  yp <- y[sub_index]
  Pi.p <- P.new[sub_index]

  xz=rbind(xu,xp) 
  yz=c(yu,yp)
  Pi.z=(r+r0)*c(Pi.u,Pi.p)
  wz=1/Pi.z
  
  fit.lpre.p = glpre(xz,yz,wz)
  beta = fit.lpre.p$beta
  t.end <- proc.time()
  
  ct <- (t.end-t.start)[3] + t_p +t_u 

  return(list(beta=beta,ct=ct,wz=wz,xz=xz,yz=yz) )
}

#CSL estimator based on least product relative error loss 
dlpre <- function(x, y, nmachine=2, B=1,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- txj %*% (yinv[groups[[j]]] * exp(x[groups[[j]], ] %*% par) 
                   - y[groups[[j]]]*exp(-x[groups[[j]], ] %*% par)) 
    fj
  }
  
  x1 <- x[groups[[1]], ]
  y1 <- y[groups[[1]]]
  tx1 <- tx[, groups[[1]]] 
  yinv1 <- yinv[groups[[1]]]
  
  ## Calculate the initial estimate for the first machine
  t.start <- proc.time()
  par <- glpre(x1, y1, 1)$beta
  
  # par_sum <- sapply(1:nmachine, function(j){glpre(x[groups[[j]], ], y[groups[[j]]])$beta})#�õ�һ��p*k�ľ���
  # t1 <- proc.time()
  # t_par = (t1-t.start)[3]/nmachine
  # par <- rowMeans(par_sum)
  time1 <- 0
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para)
    for (e in 1:1000) {
      f1 <- cd(1) 
      d1 <- yinv1*exp(x1 %*% par) + y1*exp(-x1 %*% par)
      f_diff1 <-  tx1 %*% ( x1*c(d1))
      b.est <- par - solve(f_diff1) %*% (f1 - para[, 1] + f)
      if(norm(b.est-par,"2") < 1e-6) break
      par <- b.est
    }
  }
  t.end <- proc.time()
  running.time <- (t.end-t.start)[3] - (nmachine-1)*time1 #- (nmachine-1)*t_par
  return(list(beta=b.est,running_time=running.time ))
}

dlpre_u <- function(x, y, r,nmachine=2, B=1,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- txj %*% (yinv[groups[[j]]] * exp(x[groups[[j]], ] %*% par) 
                   - y[groups[[j]]]*exp(-x[groups[[j]], ] %*% par)) 
    fj
  }
  
  ## Calculate the gradient on pilot sample
  cd_u <- function(par){
    txu %*% (yinvu * exp(xu %*% par) - yu*exp(-xu %*% par)) 
  }
  
  ## get the pilot estimator and pilot sample
  fit.lpre.u = lpre_u(x, y, r,nmachine)
  par = fit.lpre.u$beta
  t_u = fit.lpre.u$ct
  xu = fit.lpre.u$xu
  yu = fit.lpre.u$yu
  
  t.start <- proc.time()
  
  txu = t(xu)
  yinvu = 1/yu
  
  time1 <- 0
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para)/n 
    cdu = cd_u(par)/length(yu)
    for (e in 1:1000) {
      fu <- cd_u(par)/length(yu) 
      du <- yinvu*exp(xu %*% par) + yu*exp(-xu %*% par)
      f_diffu <-  txu  %*% (xu*c(du))
      f_diffu = f_diffu/length(yu) 
      b.est <- par - solve(f_diffu) %*% (fu - cdu + f)
      if(norm(b.est-par,"2") < 1e-6) break
      par <- b.est
    }
  }
  t.end <- proc.time()
  ct <- (t.end-t.start)[3] - (nmachine-1)*time1 +t_u
  return(list(beta=b.est,ct=ct,xu=xu,yu=yu))
}

dlpre_p <- function(x, y, r0,r,tau,nmachine=2, B=1,alpha.case,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- txj %*% ((yinv[groups[[j]]] * exp(x[groups[[j]], ] %*% par) 
                    - y[groups[[j]]]*exp(-x[groups[[j]], ] %*% par)))#
    fj
  }
  
  ## Calculate the gradient on subsample sample
  cd_p <- function(par){
    txp %*% ((yinvp * exp(xp %*% par) - yp*exp(-xp %*% par))*wp)/N 
  }
  
  ## get the possion suasample and subsample estimator
  fit.lpre.p = lpre_p(x, y, r0,r,tau,nmachine,alpha.case)
  par = fit.lpre.p$beta
  t_p = fit.lpre.p$ct
  xp = fit.lpre.p$xz
  yp = fit.lpre.p$yz
  wp = fit.lpre.p$wz
  
  t.start <- proc.time()
  
  txp = t(xp)
  yinvp = 1/yp
  
  time1 <- 0
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para)/n 
    cdp = cd_p(par)
    for (e in 1:1000) {
      fp <- cd_p(par) 
      dp <- (yinvp*exp(xp %*% par) + yp*exp(-xp %*% par))*wp
      f_diffp <-  txp %*% ( xp*c(dp)) 
      f_diffp = f_diffp/N
      b.est <- par - solve(f_diffp) %*% (fp - cdp + f)
      if(norm(b.est-par,"2") < 1e-6) break
      par <- b.est
    }
  }
  t.end <- proc.time()
  ct <- (t.end-t.start)[3] - (nmachine-1)*time1 +t_p
  return(list(beta=b.est,ct=ct,xp=xp,yp=yp,wp=wp))
}

#plot AEE (parameter estimation) on r1
AEE.plot.r <- function(aee, aeesd, xlabel, ylabel, xname, yname, title){
  method.names = c( "GLPRE","DLPRE-P", "DLPRE-U","DDLPRE", "ALPRE", "LPRE-P", "LPRE-U","LPRE-F")
  dat = data.frame(xlabel=1:length(xlabel), aee=as.vector(aee),
                   aeesd=as.vector(aeesd), Method=rep(method.names, each=length(xlabel)))
  dat$Method <-factor(dat$Method, levels = method.names)
  fig = ggplot(data=dat, aes(x=xlabel, y=aee, fill=Method, shape=Method, 
                             colour=Method, group= Method))+
    #geom_errorbar(aes(ymin=aee-aeesd, ymax=aee+aeesd), size=0.5, width=0.2)+
    geom_line(linetype=2,linewidth=0.6) + #linewidth=0.6
    scale_fill_brewer(palette = "Set1")+
    #scale_color_manual(values=c("red", "black","blue", "green", "orange"))+
    #scale_color_manual(values = c(2,1,3,4,5))+
    geom_point(size=2) + scale_shape_manual(values = c(15,16,17,18,0,1,2,5))+
    scale_x_discrete(limits = as.factor(xlabel))+ 
    theme_bw()+
    scale_y_log10()+
    xlab(xname) + ylab(yname)+
    labs(title  = title)+  
    theme(plot.caption=element_text(colour = "black", hjust=0.5))
  fig
}

#Non-sparse models  (parameter estimation)
DGPfunA <- function(N, rho, case, error.type){
  if(case==1){
    p = 20;beta = rep(c(1,1.5),p/2)
  }else{p=60;beta = rep(c(1,1.5),p/2)}
  
  xx =  matrix(rnorm(N*p), N, p)
  
  if(rho==0){
    X=xx
  }else{
    corrmat = toeplitz(rho^(0:(p-1)))
    cholmat = chol(corrmat)            #chol(A) = A'A
    X = xx %*% cholmat
  }
  
  lpdf1 = function(x){ -x-1/x-log(x)+2 }              
  gen1 = ars.new(logpdf=lpdf1, lb=0.0000001, ub=Inf)
  f = function(x){ (1/2)*x^2-(1/2)*0.25-log(x)+log(0.5) }
  epsilon = switch(error.type, ur(gen1, N), rlnorm(N), exp(runif(N, -2, 2)))
  Y = exp(X%*%beta)*epsilon
  return(list(Y=Y, X=X, beta=beta))
}

