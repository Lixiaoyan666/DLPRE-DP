source("functions1.R")

N=100000#200000
rho=0.5
case=1 #2
S=500
r0=120
tau=0.5
error.type=1#2,3
alpha.case=1#2
dist.type=2#1

nmachine = c( 500,400,200,100,50,25)
AEE = AEESD = matrix(,length(nmachine),8)
ACT = ACTSD = matrix(,length(nmachine),3)

for (k in 1:length(nmachine)) {
  cores <- detectCores()-2
  cl <- makeCluster(cores)
  registerDoParallel(cl, cores=cores)
  sim.res = foreach(i=1:S, .packages =c("matrixStats", "MASS", "glmnet","Runuran")) %dopar%
    {
      #nmachine = c( 100,80,50,40,25,20)
      n = N/nmachine[k]
      
      Data = DGPfunA(N=N, rho=rho, case=case, error.type)
      x = Data$X
      y = Data$Y
      beta = Data$beta
      
      fit.glpre = glpre(x, y,w=1)
      beta_g = fit.glpre$beta
      ct_g = fit.glpre$ct
      aee_g = norm(beta_g-beta, "2")
      
      beta_a = alpre(x, y, nmachine=nmachine[k], dist.type)$beta
      aee_a = norm(beta_a-beta, "2")
      
      fit.dlpre = dlpre(x, y, nmachine=nmachine[k], B=1, dist.type)
      beta_c = fit.dlpre$beta
      aee_c = norm(beta_c-beta, "2")
      
      fit.lpre_f = lpre_f(x, y, nmachine=nmachine[k], dist.type)
      beta_f = fit.lpre_f$beta
      aee_f = norm(beta_f-beta, "2")
      
      fit.lpre_u = lpre_u(x, y, r=n,nmachine=nmachine[k])
      beta_u = fit.lpre_u$beta
      aee_u = norm(beta_u-beta, "2")
      
      fit.lpre_p = lpre_p(x, y, r0, r=n-r0, tau,nmachine=nmachine[k],alpha.case)
      beta_p = fit.lpre_p$beta
      aee_p = norm(beta_p-beta, "2")
      
      fit.dlpre_u = dlpre_u(x, y,r=n, nmachine=nmachine[k], B=1,dist.type)
      beta_cu = fit.dlpre_u$beta
      aee_cu = norm(beta_cu-beta, "2")
      ct_cu = fit.dlpre_u$ct
      
      fit.dlpre_p = dlpre_p(x, y, r0, r=n-r0, tau,nmachine=nmachine[k],alpha.case, B=1,dist.type)
      beta_cp = fit.dlpre_p$beta
      ct_cp = fit.dlpre_p$ct
      aee_cp = norm(beta_cp-beta, "2")
      
      aee=c(aee_g,aee_cp, aee_cu,aee_c,aee_a, aee_p,aee_u,aee_f)
      ct = c(ct_g,ct_cp,ct_cu)
      
      return(list(EE=aee,CT=ct))
    }    
  
  stopImplicitCluster()
  stopCluster(cl)
  ee <- ct <- list()
  for (s in 1:length(sim.res)) {
    ee[[s]] <- sim.res[[s]]$EE
    ct[[s]] <- sim.res[[s]]$CT
  }
  AEE[k,] = Reduce("+",ee)/length(ee)
  AEESD[k,] <- apply(array(unlist(ee), c(1,8, S)), c(1,2), sd)
  ACT[k,] <- Reduce("+",ct)/length(ee)
  ACTSD[k,] <- apply(array(unlist(ct), c(1,3, S)), c(1,2), sd)
}
colnames(AEE) = c( "GLPRE", "DLPRE-P", "DLPRE-U","DLPRE", "ALPRE", "LPRE-P", "LPRE-U","LPRE-F")
colnames(ACT) = c( "GLPRE", "DLPRE-P", "DLPRE-U")

xname = "percentage of subsample"
xlabel = 1/nmachine
plot = AEE.plot.r(AEE, AEESD, xlabel, ylabel=AEE, xname, yname="AEE", title="error distribution d1")
AEE
AEESD
ACT
ACTSD



