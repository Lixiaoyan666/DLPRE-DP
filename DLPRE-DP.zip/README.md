# DLPRE-P estimator

Distributed subsampling for relative-error multiplicative models with a diverging number of parameters

Paper: Li X., Xia X. and Zhang Z. (2024+). Distributed subsampling for relative-error multiplicative models with a diverging number
of parameters. Submit to journal.


