Sys.setlocale("LC_ALL","Chinese") # ���Ӣ��ϵͳ�µ�����

library(ggplot2)
library(ggpubr)
library(RColorBrewer)  
library(Runuran)
library(matrixStats)
library(doParallel) 
library(doSNOW)
library(foreach)
library(glmnet)
library(dfoptim)  # derivative-free optimization 
library(ggforce)
library(parallel)
library(MASS)



#global least product relative error estimator
glpre <- function(x, y, w){
  x <- as.matrix(x)
  y <- as.vector(y)
  n <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  t1 <- proc.time()
  par <- coef(lm(log(y)~x+0))
  t2 <- proc.time()
  b.est <- par+100 
  for(k in 1:1000){
    f <- tx %*% ((yinv * exp(x %*% par) - y*exp(-x %*% par))*w) 
    tt <- (yinv*exp(x %*% par)+y*exp(-x %*% par))*w 
    f_diff=tx %*% (x*c(tt)) 
    b.est <- par-solve(f_diff)%*%f
    if(norm(b.est - par,"2")<=1e-6) break
    par <- b.est
  }
  t3 <- proc.time()
  return(list(beta=b.est,ct=(t3-t1)[3]))
}

#penalized global least product relative error estimator
gplpre <- function(x, y, lambda=NULL, gamma=1){
  N <- length(y)
  p <- ncol(x)
  t1 <- proc.time()
  beta.glpre <- glpre(x, y,1)$beta
  if(all(x[,1]==1)){ 
    intercept <- TRUE
    x <- x[, -1]
    beta.glpre <- beta.glpre[-1]
  }else{
    intercept <- FALSE
  }
  if(is.null(lambda)){
    lambda_max <- max(abs(t(x) %*% log(y))/N)
    lambda_min <- lambda_max * 1e-3
    lambda1 <- seq(log(lambda_max), log(lambda_min), length=50)
    lambda <- exp(lambda1)
  }
  
  w <- 1/abs(1/N+abs(beta.glpre))^gamma 
  fit <- lpre.admm(x, y, lambda=lambda, intercept=intercept, 
                   normalize=FALSE, gamma = gamma, penalty.factor=w) 
  xx <- as.matrix(cbind(1, x))
  y <- as.vector(y)
  dbic <- log(colMeans((y - exp(xx%*%fit$beta))^2/(y*exp(xx%*%fit$beta)))) + fit$df*log(N)/N
  if(intercept){
    beta <- fit$beta
  }else{
    beta <- fit$beta[-1, ]
  }
  t2 <- proc.time()
  return(list(beta=beta, df=fit$df, lambda=fit$lambda, dbic=dbic,ct=(t2-t1)[3]))
}

#average least product relative error estimator
alpre <- function(x, y, nmachine=2,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  w <- list()
  for (j in 1:nmachine) {
    w[[j]] <- rep(1,length(y[groups[[j]]]))
  }
  t1 <- proc.time()
  para <- sapply(1:nmachine, function(j){glpre(x[groups[[j]], ], y[groups[[j]]],w[[j]])$beta})#�õ�һ��p*k�ľ���
  t2 <- proc.time()
  b.est <- rowMeans(para)
  t3 <- proc.time()
  running.time <-(t2-t1)[3]/nmachine + (t3-t2)[3]
  return(list(beta=b.est,running_time=running.time))
}

#penalized average least product relative error estimator
aplpre <- function(x, y, nmachine=2,lambda=NULL,gamma=1,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  t.start=proc.time()
  if(is.null(lambda)){
    lambda_max <- max(abs(t(x) %*% log(y))/N)
    lambda_min <- lambda_max * 1e-3
    lambda1 <- seq(log(lambda_max), log(lambda_min), length=50)
    lambda <- exp(lambda1)
  }
  t1=proc.time()
  para <- sapply(1:nmachine, function(j){
    fit <- gplpre(x[groups[[j]], ], y[groups[[j]]], lambda = lambda, gamma = gamma)
    fit$beta[, which.min(fit$dbic)]})
  t2=proc.time()
  time1=(t2-t1)[3]/nmachine
  beta <- rowMeans(para)
  df <- length(which(beta!=0))
  t.end=proc.time()
  running.time <- (t.end-t.start)[3] - (nmachine-1)*time1 
  return(list(beta=beta, df=df, lambda=lambda,running_time=running.time))
}

#penalized CSL estimator based on least product relative error loss (our method)
dplpre <- function(x, y, nmachine=2,lambda=NULL,  B=1, gamma=1,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- txj %*% (yinv[groups[[j]]] * exp(x[groups[[j]], ] %*% par) 
                   - y[groups[[j]]]*exp(-x[groups[[j]], ] %*% par)) 
    fj
  }
  
  x1 <- x[groups[[1]], ]
  y1 <- y[groups[[1]]]
  tx1 <- tx[, groups[[1]]] 
  yinv1 <- yinv[groups[[1]]]
  
  solvelpre <- function(a, b, u, rho){
    D1 <- tx1 %*% (yinv1*exp(x1 %*% b) - y1*exp(-x1 %*% b))/n - para[, 1]/n + f/N
    tt <- yinv1*exp(x1 %*% b) + y1*exp(-x1 %*% b)
    D2 <- tx1 %*% ( x1*c(tt))/n
    D.inverse <- solve(D2+diag(rho, p))
    q <- rho * a - u + D2 %*% b - D1
    beta <- D.inverse %*% q
    return(beta)
  }
  
  ##solve penlity lpre function 
  penlpre <- function(lambdaj){
    rho <- 1#; alpha <- 1.8
    ak <- uk <- rep(0,p)
    bk <- par
    w <- lambdaj/(1/n + abs(par))^gamma
    if(all(x[, 1]==1)) {w[1] <- 0}
    maxiter <- 300
    eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
    for (k in 1 : maxiter) {
      bnew <- solvelpre(ak, bk, uk, rho)
      #bnew <- alpha * bnew + (1 - alpha) * ak
      s <- bnew + uk/rho
      anew <- sign(s)*pmax(abs(s)-w/rho, 0)
      unew <- uk + rho * (bnew -anew)   
      
      if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
         norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
      #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
      
      bk <- bnew
      ak <- anew
      uk <- unew
    }
    return(c(k, length(which(anew!=0)), anew))
  }
  
  ## Calculate the initial estimate for the first machine
  t.start <- proc.time()
  par <- glpre(x1, y1,1)$beta
  #par_sum <- sapply(1:nmachine, function(j){glpre(x[groups[[j]], ], y[groups[[j]]],1)$beta})#�õ�һ��p*k�ľ���
  #t1 <- proc.time()
  #t_par = (t1-t.start)[3]/nmachine
  #par <- rowMeans(par_sum)
  time1 <- 0
  if(length(lambda)!=1){B <- 1}
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para)
    f1 <- cd(1)
    res <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
    iter <- res[1, ]
    df <- res[2, ]
    beta <- res[-c(1,2), ]
    par <- beta
  }
  y1 <- as.vector(y1)
  dbic <- log(colMeans((y1 - exp(x1%*%beta))^2/(y1*exp(x1%*%beta)))-t(beta)%*%(f1/n-f/N)
              +t(par)%*%(f1/n-f/N)-colMeans((y1 - exp(x1%*%par))^2/(y1*exp(x1%*%par)))
              +colMeans((y - exp(x%*%par))^2/(y*exp(x%*%par))))+df*log(N)/N
  t.end <- proc.time()
  running.time <- (t.end-t.start)[3] -(nmachine-1)*time1 # -(nmachine-1)*t_par
  return(list(beta=beta, df=df, lambda=lambda, dbic=dbic,running_time=running.time))
}

#ADMM algorithm for gplpre
lpre.admm <- function(x, y, lambda=NULL, intercept=FALSE, normalize=FALSE, 
                      gamma=0, penalty.factor=rep(1, ncol(x))){
  x <- as.matrix(x)
  y <- as.matrix(y)
  np <- dim(x)
  n <- np[1]
  p <- np[2]
  
  if(intercept){
    meanx <- colMeans(x)
    mprody <- max(abs(y))*prod(y/max(abs(y)))^(1/n) 
  }else{
    meanx <- rep(0, p)
    mprody <- 1
  }
  x <- scale(x, meanx, FALSE) 
  if(normalize){normx <- sqrt(colSums(x^2)) }else{ normx <- rep(1, p)}
  x <- scale(x, FALSE, normx)
  y <- y/mprody 
  tx <- t(x)
  
  if(is.null(lambda)) {
    lambda_max<-max(abs(tx%*%log(y))/n)
    lambda_min<-lambda_max * 1e-3
    lambda1<-seq(log(lambda_max), log(lambda_min), length=50)
    lambda<-exp(lambda1)
  } 
  
  solvelpre <- function(a, b, u, rho){
    D1 <- tx %*% (1/y*exp(x %*% b) - y*exp(-x %*% b))/n 
    tt <- 1/y*exp(x %*% b) + y*exp(-x %*% b)
    D2 <- tx %*% ( x*c(tt))/n  
    D.inverse <- solve(D2+diag(rho, p))
    q <- rho * a - u + D2 %*% b - D1
    beta <- D.inverse %*% q
    return(beta)
  }
  
  
  ##solve penlity lpre function 
  penlpre <- function(lambdaj){
    rho <- 1#; alpha <- 1.8
    ak <- bk <- uk <- rep(0,p)
    w <- lambdaj*penalty.factor^gamma
    if(n > p) bk <- lm(log(y) ~ x + 0)$coef 
    maxiter <- 300
    eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
    for (k in 1 : maxiter) {
      bnew <- solvelpre(ak, bk, uk, rho)
      #bnew <- alpha * bnew + (1 - alpha) * ak
      s <- bnew + uk/rho
      anew <- sign(s)*pmax(abs(s)-w/rho, 0)
      unew <- uk + rho * (bnew -anew)   
      
      if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
         norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
      #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
      
      bk <- bnew
      ak <- anew
      uk <- unew
    }
    return(c(k, length(which(anew!=0)), anew))
  }
  
  para <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
  iter <- para[1, ]
  df <- para[2, ]
  b <- scale(t(para[-c(1,2), ]), FALSE, normx)
  esti <- rbind(log(mprody) - meanx %*% t(b), t(b))
  
  return(list(beta=esti, lambda=lambda, df=df, iter=iter))
}

lpre_u <- function(x, y,r,nmachine){
  ##Method 2
  #x=X;y=Y;r0=n
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ## define the random pilot sample
  #q=0.1
  #a = q*N/nmachine
  #pilot_index = as.vector(sapply(1:nmachine, function(j){sample(groups[[j]],a)}))#sapply�Ľ��Ϊһ������
  t1 <- proc.time()
  index <- 1:N
  pi <- rep((r/N),N)
  decision <- rbinom(N,rep(1,N),prob=pi)#rbinom(n, size, prob)����n��b(size, prob)�Ķ���ֲ������
  pilot_index <- index[decision==1]
  t2 <- proc.time()
  t_p = (t2[3]-t1[3])/nmachine
  
  t.start <- proc.time()
  
  xu <- x[pilot_index, ]
  yu <- y[pilot_index]
  
  
  ## Calculate the initial estimate on pilot sample
  fit.glpre.u = glpre(xu,yu,1)
  beta = fit.glpre.u$beta
  #t_beta = fit.glpre.u$ct
  t.end <- proc.time()
  
  ct <- (t.end-t.start)[3] + t_p
  
  return(list(beta=beta, ct=ct,xu=xu,yu=yu))
}

lpre_p <- function(x, y, r0, r,tau,nmachine,alpha.case){
  ##Method 2
  #x=X;y=Y;r0;r=1000;tau = 0.1
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  p <- ncol(x)
  
  if(alpha.case==1){
    alpha <- diag(rep(1,p))
  }else{
    if(alpha.case==2){
      alpha <- rep(1,p)
    }else{
      alpha <- c(1,rep(0,p-1))  #rep(1/p,p)
    }
  } 
  
  ## get the pilot estimator and pilot sample
  fit.lpre.u = lpre_u(x, y, r0,nmachine)
  par0 = fit.lpre.u$beta
  t_u = fit.lpre.u$ct
  xu = fit.lpre.u$xu
  yu = fit.lpre.u$yu
  
  
  ## Calculate the subsampling probability and get the subsample
  t1 <- proc.time()
  epsilon.u = yu*exp(-xu %*% par0)
  D <- t(xu)%*%(xu*c(epsilon.u^{-1}+epsilon.u))/length(yu)  #������Ϣ����D_N_hat
  phi_hat <- sum(abs(epsilon.u^{-1} -epsilon.u)* (colSums((alpha %*%solve(D) %*% t(xu))^2))^{1/2})/length(yu)
  t2 <- proc.time()
  epsilon = y*exp(-x %*% par0)
  h <- abs(epsilon^{-1} - epsilon)* (colSums((alpha %*%solve(D) %*% t(x))^2))^{1/2}
  #phi_hat <- sum(abs(yinvu * exp(xu %*% par0) - yu*exp(-xu %*% par0))* ((rowSums(xu^2))^(1/2)))/length(yu)
  P <- h/(N*phi_hat)
  P.new <- abs((1-tau)*P+tau/N+1/(r+1e-6))/2-abs((1-tau)*P+tau/N-1/(r+1e-6))/2#ȡPi^1
  index <- 1:N
  eta <- rbinom(N,rep(1,N),prob=r*P.new)#rbinom(n, size, prob)����n��b(size, prob)�Ķ���ֲ������
  sub_index <- index[eta==1]
  #w <- 1/Pi
  t3 <- proc.time()
  t_p = (t3-t2)[3]/nmachine + (t2-t1)[3]
  
  t.start <- proc.time()
  
  ## Calculate the subsample estimator
  Pi.u <- rep(1/N,length(yu))# ע������ӳ�������Ϊ1/N
  
  xp <- x[sub_index, ]
  yp <- y[sub_index]
  Pi.p <- P.new[sub_index]
  
  xz=rbind(xu,xp) #��r0��r��Ϻ��x
  yz=c(yu,yp)
  Pi.z=(r+r0)*c(Pi.u,Pi.p)
  wz=1/Pi.z
  
  fit.lpre.p = glpre(xz,yz,wz)
  beta = fit.lpre.p$beta
  t.end <- proc.time()
  
  ct <- (t.end-t.start)[3] + t_p +t_u 
  
  return(list(beta=beta,ct=ct,wz=wz,xz=xz,yz=yz) )
}


plpre_f <- function(x, y, nmachine=2,lambda=NULL, gamma=1,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  x1 <- x[groups[[1]], ]
  y1 <- y[groups[[1]]]
  
  fit.plpre.f <- gplpre (x1, y1, lambda=NULL, gamma=1)
  
  return(list(beta=fit.plpre.f$beta, df=fit.plpre.f$df, lambda=fit.plpre.f$lambda, dbic=fit.plpre.f$dbic,ct=fit.plpre.f$ct))
}

plpre_u <- function(x, y, r,nmachine=2,lambda=NULL, gamma=1){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ## get the uniform subsample estimator and subsample estimator
  fit.lpre.u = lpre_u(x, y, r,nmachine)
  xu = fit.lpre.u$xu
  yu = fit.lpre.u$yu
  t_u = fit.lpre.u$ct
  
  fit.plpre.u <- gplpre (xu, yu, lambda=NULL, gamma=1)
  
  return(list(beta=fit.plpre.u$beta, df=fit.plpre.u$df, lambda=fit.plpre.u$lambda, dbic=fit.plpre.u$dbic,ct=fit.plpre.u$ct+t_u))
}

plpre_p <- function(x, y, r0,r,tau,nmachine=2,lambda=NULL, gamma=1,alpha.case){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  
  lpre.p.admm <- function(xp, yp, wp,lambda=NULL, intercept=FALSE, normalize=FALSE, 
                        gamma=0, penalty.factor=rep(1, ncol(xp))){
    xp <- as.matrix(xp)
    yp <- as.matrix(yp)
    np <- dim(xp)
    n <- np[1]
    p <- np[2]
    
    if(intercept){
      meanxp <- colMeans(xp)
      mprodyp <- max(abs(yp))*prod(yp/max(abs(yp)))^(1/n) 
    }else{
      meanxp <- rep(0, p)
      mprodyp <- 1
    }
    xp <- scale(xp, meanxp, FALSE) 
    if(normalize){normxp <- sqrt(colSums(xp^2)) }else{ normxp <- rep(1, p)}
    xp <- scale(xp, FALSE, normxp)
    yp <- yp/mprodyp 
    txp <- t(xp)
    
    if(is.null(lambda)) {
      lambda_max<-max(abs(txp%*%log(yp))/n)
      lambda_min<-lambda_max * 1e-3
      lambda1<-seq(log(lambda_max), log(lambda_min), length=50)
      lambda<-exp(lambda1)
    } 
    
    #Approximation algorithm to solve beta (SQP)
    solvelpre <- function(a, b, u, rho){
      D1 <- txp %*% ((1/yp*exp(xp %*% b) - yp*exp(-xp %*% b))*wp/N)
      tt <- (1/yp*exp(xp %*% b) + yp*exp(-xp %*% b))*wp/N
      D2 <- txp %*% ( xp*c(tt))
      D.inverse <- solve(D2+diag(rho, p))
      q <- rho * a - u + D2 %*% b - D1
      beta <- D.inverse %*% q
      return(beta)
    }
    
    
    ##solve penlity lpre function 
    penlpre <- function(lambdaj){
      rho <- 1#; alpha <- 1.8
      ak <- bk <- uk <- rep(0,p)
      w <- lambdaj*penalty.factor^gamma
      if(n > p) bk <- lm(log(yp) ~ xp + 0)$coef 
      maxiter <- 300
      eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
      for (k in 1 : maxiter) {
        bnew <- solvelpre(ak, bk, uk, rho)
        #bnew <- alpha * bnew + (1 - alpha) * ak
        s <- bnew + uk/rho
        anew <- sign(s)*pmax(abs(s)-w/rho, 0)
        unew <- uk + rho * (bnew -anew)   
        
        if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
           norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
        #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
        
        bk <- bnew
        ak <- anew
        uk <- unew
      }
      return(c(k, length(which(anew!=0)), anew))
    }
    
    para <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
    iter <- para[1, ]
    df <- para[2, ]
    b <- scale(t(para[-c(1,2), ]), FALSE, normxp)
    esti <- rbind(log(mprodyp) - meanxp %*% t(b), t(b))
    
    return(list(beta=esti, lambda=lambda, df=df, iter=iter))
  }
  
  
  ## get the possion suasample and suasample estimator
  fit.lpre.p = lpre_p(x, y, r0,r,tau,nmachine,alpha.case)
  par = fit.lpre.p$beta
  t_p = fit.lpre.p$ct
  xp = fit.lpre.p$xz
  yp = fit.lpre.p$yz
  wp = fit.lpre.p$wz
  
  t1 <- proc.time()
  if(all(xp[,1]==1)){ 
    intercept <- TRUE
    xp <- xp[, -1]
    par <- par[-1]
  }else{
    intercept <- FALSE
  }
  if(is.null(lambda)){
    lambda_max <- max(abs(t(xp) %*% log(yp))/length(yp))
    lambda_min <- lambda_max * 1e-3
    lambda1 <- seq(log(lambda_max), log(lambda_min), length=50)
    lambda <- exp(lambda1)
  }
  
  w.penalty <- 1/abs(1/r+abs(par))^gamma 
  fit <- lpre.p.admm(xp, yp,wp, lambda=lambda, intercept=intercept, 
                   normalize=FALSE, gamma = gamma, penalty.factor=w.penalty) 
  xx <- as.matrix(cbind(1, xp))
  yp <- as.vector(yp)
  dbic <- log(colSums(((yp - exp(xx%*%fit$beta))^2/(yp*exp(xx%*%fit$beta)))*wp)/N) + fit$df*log(r)/r
  if(intercept){
    beta <- fit$beta
  }else{
    beta <- fit$beta[-1, ]
  }
  t2 <- proc.time()
  ct = t2[3]-t1[3] +t_p
  return(list(beta=beta, df=fit$df, lambda=fit$lambda, dbic=dbic,ct=ct))
}

#penalized clpre estimator based on uniform subsampling
dplpre_u <- function(x, y, r,nmachine=2,lambda=NULL,  B=1, gamma=1,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- txj %*% (yinv[groups[[j]]] * exp(x[groups[[j]], ] %*% par) 
                   - y[groups[[j]]]*exp(-x[groups[[j]], ] %*% par)) 
    fj
  }
  
  ## Calculate the gradient on pilot sample
  cd_u <- function(par){
    txu %*% (yinvu * exp(xu %*% par) - yu*exp(-xu %*% par))/length(yu)
  }
  
  #Approximation algorithm to solve beta (SQP)
  solvelpre <- function(a, b, u, rho){
    fu <- cd_u(b)
    D1 <- fu - cdu + f
    tt <- yinvu*exp(xu %*% b) + yu*exp(-xu %*% b)
    D2 <- txu %*% (xu*c(tt))
    D2 = D2/length(yu) 
    D.inverse <- solve(D2+diag(rho, p))
    q <- rho * a - u + D2 %*% b - D1
    beta <- D.inverse %*% q
    return(beta)
  }
  
  ##solve penlity lpre function 
  penlpre <- function(lambdaj){
    rho <- 1#; alpha <- 1.8
    ak <- uk <- rep(0,p)
    bk <- par
    w <- lambdaj/(1/r + abs(par))^gamma
    if(all(x[, 1]==1)) {w[1] <- 0}
    maxiter <- 300
    eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
    for (k in 1 : maxiter) {
      bnew <- solvelpre(ak, bk, uk, rho)
      #bnew <- alpha * bnew + (1 - alpha) * ak
      s <- bnew + uk/rho
      anew <- sign(s)*pmax(abs(s)-w/rho, 0)
      unew <- uk + rho * (bnew -anew)   
      
      if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
         norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
      #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
      
      bk <- bnew
      ak <- anew
      uk <- unew
    }
    return(c(k, length(which(anew!=0)), anew))
  }
  
  
  ## get the uniform subsample and subsample estimator as the initial estimate
  fit.lpre.u = lpre_u(x, y,r,nmachine)
  xu = fit.lpre.u$xu
  yu = fit.lpre.u$yu
  par = fit.lpre.u$beta
  t_u = fit.lpre.u$ct
  
  t.start <- proc.time()
  txu = t(xu)
  yinvu = 1/yu
  
  time1 <- 0
  if(length(lambda)!=1){B <- 1}
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para)/n 
    cdu <- cd_u(par)    
    res <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
    iter <- res[1, ]
    df <- res[2, ]
    beta <- res[-c(1,2), ]
    par <- beta
  }
  yu <- as.vector(yu)
  dbic <- log(colMeans((yu - exp(xu%*%beta))^2/(yu*exp(xu%*%beta)))-t(beta)%*%(cdu-f)
              +t(par)%*%(cdu-f)-colMeans((yu - exp(xu%*%par))^2/(yu*exp(xu%*%par)))
              +colMeans((y - exp(x%*%par))^2/(y*exp(x%*%par))))+df*log(N)/N
  t.end <- proc.time()
  ct <- (t.end-t.start)[3] -(nmachine-1)*time1 +t_u
  return(list(beta=beta, df=df, lambda=lambda, dbic=dbic,ct=ct,iter=iter))
}

##penalized clpre estimator based on possion subsampling (our method)
dplpre_p <- function(x, y, r0,r,tau, nmachine=2,lambda=NULL, B=1, gamma=1,alpha.case,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- txj %*% (yinv[groups[[j]]] * exp(x[groups[[j]], ] %*% par) 
                   - y[groups[[j]]]*exp(-x[groups[[j]], ] %*% par)) 
    fj
  }
  
  ## Calculate the gradient on subsample sample
  cd_p <- function(par){
    txp %*% ((yinvp * exp(xp %*% par) - yp*exp(-xp %*% par))*wp)/N 
  }
  
  
  #Approximation algorithm to solve beta (SQP)
  solvelpre <- function(a, b, u, rho){
    fp <- cd_p(b)
    D1 <- fp - cdp + f
    tt <- (yinvp*exp(xp %*% b) + yp*exp(-xp %*% b))*wp
    D2 <- txp %*%  (xp*c(tt))
    D2 = D2/N
    D.inverse <- solve(D2+diag(rho, p))
    q <- rho * a - u + D2 %*% b - D1
    beta <- D.inverse %*% q
    return(beta)
  }
  
  ##solve penlity lpre function 
  penlpre <- function(lambdaj){
    rho <- 1#; alpha <- 1.8
    ak <- uk <- rep(0,p)
    bk <- par
    w <- lambdaj/(1/r + abs(par))^gamma
    if(all(x[, 1]==1)) {w[1] <- 0}
    maxiter <- 300
    eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
    for (k in 1 : maxiter) {
      bnew <- solvelpre(ak, bk, uk, rho)
      #bnew <- alpha * bnew + (1 - alpha) * ak
      s <- bnew + uk/rho
      anew <- sign(s)*pmax(abs(s)-w/rho, 0)
      unew <- uk + rho * (bnew -anew)   
      
      if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
         norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
      #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
      
      bk <- bnew
      ak <- anew
      uk <- unew
    }
    return(c(k, length(which(anew!=0)), anew))
  }
  
  
  ## get the possion suasample and suasample estimator as the initial estimate
  fit.lpre.p = lpre_p(x, y, r0,r,tau,nmachine,alpha.case)
  xp = fit.lpre.p$xz
  yp = fit.lpre.p$yz
  par = fit.lpre.p$beta
  t_p = fit.lpre.p$ct
  wp = fit.lpre.p$wz
  
  t.start <- proc.time()
  txp = t(xp)
  yinvp = 1/yp
  
  time1 <- 0
  if(length(lambda)!=1){B <- 1}
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para)/n 
    cdp <- cd_p(par) 
    res <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
    iter <- res[1, ]
    df <- res[2, ]
    beta <- res[-c(1,2), ]
    par <- beta
  }
  yp <- as.vector(yp)
  dbic <- log(colSums(((yp - exp(xp%*%beta))^2/(yp*exp(xp%*%beta)))*wp)/N-t(beta)%*%(cdp-f)
              +t(par)%*%(cdp-f)-colSums(((yp - exp(xp%*%par))^2/(yp*exp(xp%*%par)))*wp)/N
              +colMeans((y - exp(x%*%par))^2/(y*exp(x%*%par))))+df*log(N)/N
  t.end <- proc.time()
  ct <- (t.end-t.start)[3] -(nmachine-1)*time1  + t_p
  return(list(beta=beta, df=df, lambda=lambda, dbic=dbic,ct=ct,iter=iter))
}

#Sparse models  (variable selection)
DGPfunB <- function(N, rho, case, error.type){
  if(case==1){
    p = 10; beta = c(2,1.5,1,0.8,0.5,rep(0,p-5))
  }else{p=60; beta = c(2,1.5,1,0.8,0.5,rep(0,p-5))}
  
  xx =  matrix(rnorm(N*p), N, p)
  
  if(rho==0){
    X=xx
  }else{
    corrmat = toeplitz(rho^(0:(p-1)))
    cholmat = chol(corrmat)            #chol(A) = A'A
    X = xx %*% cholmat
  }
  
  lpdf1 = function(x){ -x-1/x-log(x)+2 }              
  gen1 = ars.new(logpdf=lpdf1, lb=0.0000001, ub=Inf)
  f = function(x){ (1/2)*x^2-(1/2)*0.25-log(x)+log(0.5) }
  epsilon = switch(error.type, ur(gen1, N), rlnorm(N), exp(runif(N, -2, 2)))
  
  Y = exp(X%*%beta)*epsilon
  return(list(Y=Y, X=X, beta=beta))
}
