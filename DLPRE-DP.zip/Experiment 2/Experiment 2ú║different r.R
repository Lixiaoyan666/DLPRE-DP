
source("functions2.R")

N=100000#200000
rho=0.5
case=1 #2
S=500
r0=120
tau=0.5
error.type=1#2,3
alpha.case=1#2
dist.type=2#1

AEE = AEE_SD = AMS = AMS_SD = ACF = ACF_SD = vector("list", 3)  
ACT = ACT_SD = vector("list", 3)  
nmachine = c( 200,100,50,25)

cores <- detectCores()-2
cl <- makeCluster(cores)
registerDoParallel(cl, cores=cores)
sim.res <- foreach(aa=1:S, .packages =c("matrixStats", "MASS", "glmnet","Runuran")) %dopar%
  {
    dat = DGPfunB(N=N, rho=rho, case=case, error.type=error.type)
    X = dat$X
    Y = dat$Y
    beta = dat$beta
    
    lambda_max<-max(abs(t(X)%*%log(Y))/N)
    lambda_min<-lambda_max * 1e-3
    lambda1<-seq(log(lambda_max), log(lambda_min), length=50)
    lambda<-exp(lambda1)
    
    nmachine = c( 200,100,50,25)
    
    fit_gplpre = gplpre(X, Y, lambda=lambda,gamma=1)
    t_gplpre_1 = proc.time()
    gplpre_beta = fit_gplpre$beta[, which.min(fit_gplpre$dbic)]
    t_gplpre_2 = proc.time()
    ct_pg = rep(t_gplpre_2[3]-t_gplpre_1[3] +fit_gplpre$ct,length(nmachine))
    ee_pg = rep(norm(gplpre_beta-beta, "2"),length(nmachine))
    ms_pg = rep(sum(gplpre_beta!=0),length(nmachine))
    poi = which(beta!=0)
    fp_pg = sum(gplpre_beta[-poi]!=0)/ sum(beta==0)
    fn_pg = sum(gplpre_beta[poi]==0)/ sum(beta!=0)
    cf_pg = rep((fp_pg+fn_pg==0),length(nmachine))  
    
    ee_k = matrix(,length(nmachine),7)
    ct_k = matrix(,length(nmachine),2)
    ms_k = matrix(,length(nmachine),7)
    fp_k = matrix(,length(nmachine),7)
    fn_k = matrix(,length(nmachine),7)
    cf_k = matrix(,length(nmachine),7)
    
    for(k in 1:length(nmachine)){
      
      n = N/nmachine[k]
      
      aplpre_beta = aplpre(X, Y, nmachine=nmachine[k],lambda=lambda, gamma=1,dist.type)$beta
      
      fit_dplpre = dplpre(X, Y, nmachine=nmachine[k],lambda=lambda, B=1, gamma=1,dist.type)
      dplpre_beta = fit_dplpre$beta[, which.min(fit_dplpre$dbic)]
      
      fit_plpre_f <- plpre_f(X, Y, nmachine=nmachine[k],lambda=lambda, gamma=1,dist.type)
      plpre_f_beta = fit_plpre_f$beta[, which.min(fit_plpre_f$dbic)]
      
      fit_plpre_u <- plpre_u(X, Y, r=n,nmachine=nmachine[k],lambda=lambda, gamma=1)
      plpre_u_beta = fit_plpre_u$beta[, which.min(fit_plpre_u$dbic)]
      
      fit_plpre_p <- plpre_p(X, Y,r0, r=n-r0,tau,nmachine=nmachine[k],lambda=lambda, gamma=1,alpha.case)
      plpre_p_beta = fit_plpre_p$beta[, which.min(fit_plpre_p$dbic)]
      
      fit_dplpre_u = dplpre_u(X, Y, r=n,nmachine=nmachine[k],lambda=lambda, B=1, gamma=1,dist.type)
      dplpre_u_beta = fit_dplpre_u$beta[, which.min(fit_dplpre_u$dbic)]
      ct_pcu = fit_dplpre_u$ct  
      
      fit_dplpre_p = dplpre_p(X, Y, r0,r=n-r0,tau, nmachine=nmachine[k],lambda=lambda,B=1, gamma=1,alpha.case,dist.type)
      dplpre_p_beta = fit_dplpre_p$beta[, which.min(fit_dplpre_p$dbic)]
      ct_pcp = fit_dplpre_p$ct  
      
      ee_k[k,] = c(norm(dplpre_p_beta-beta, "2"),norm(dplpre_u_beta-beta, "2"),
                   norm(dplpre_beta-beta,"2"),   norm(aplpre_beta-beta, "2"),  
                   norm(plpre_p_beta-beta, "2"), norm(plpre_u_beta-beta, "2"),
                   norm(plpre_f_beta-beta, "2"))
      
      ms_k[k,] = c(sum(dplpre_p_beta!=0),sum(dplpre_u_beta!=0),
                   sum(dplpre_beta!=0),  sum(aplpre_beta!=0),
                   sum(plpre_p_beta!=0), sum(plpre_u_beta!=0),
                   sum(plpre_f_beta!=0))
      
      poi = which(beta!=0)
      
      fp_k[k,] = c(sum(dplpre_p_beta[-poi]!=0),sum(dplpre_u_beta[-poi]!=0),
                   sum(dplpre_beta[-poi]!=0),  sum(aplpre_beta[-poi]!=0),
                   sum(plpre_p_beta[-poi]!=0), sum(plpre_u_beta[-poi]!=0),
                   sum(plpre_f_beta[-poi]!=0))/sum(beta==0)
      
      fn_k[k,] = c(sum(dplpre_p_beta[poi]==0),sum(dplpre_u_beta[poi]==0),
                   sum(dplpre_beta[poi]==0),  sum(aplpre_beta[poi]==0),
                   sum(plpre_p_beta[poi]==0), sum(plpre_u_beta[poi]==0),
                   sum(plpre_f_beta[poi]==0))/sum(beta!=0)
      
      cf_k[k,] = (fp_k[k,] + fn_k[k,]==0)
      ct_k[k,] = c(ct_pcu,ct_pcp)
      
    }
    ee = cbind(ee_pg, ee_k)
    ct = cbind(ct_pg, ct_k)
    ms = cbind(ms_pg, ms_k)
    cf = cbind(cf_pg, cf_k)
    
    colnames(ee) = c( "GRLPRE","DRLPRE-P", "DRLPRE-U","DRLPRE", "ARLPRE", "RLPRE-P", "RLPRE-U","RLPRE-F")
    colnames(ms) = c( "GRLPRE","DRLPRE-P", "DRLPRE-U","DRLPRE", "ARLPRE", "RLPRE-P", "RLPRE-U","RLPRE-F")
    colnames(cf) = c( "GRLPRE","DRLPRE-P", "DRLPRE-U","DRLPRE", "ARLPRE", "RLPRE-P", "RLPRE-U","RLPRE-F")
    colnames(ct) = c( "GRLPRE","DRLPRE-P", "DRLPRE-U")
    
    return(list(EE=ee, MS=ms, CF=cf, CT=ct))
  }
stopImplicitCluster()
stopCluster(cl)

ee <- ms <-  cf <- ct <-list()
for (s in 1:length(sim.res)) {
  ee[[s]] <- sim.res[[s]]$EE 
  ms[[s]] <- sim.res[[s]]$MS
  
  cf[[s]] <- sim.res[[s]]$CF
  ct[[s]] <- sim.res[[s]]$CT
}
AEE <- Reduce("+",ee)/length(ee)
AEESD <- apply(array(unlist(ee), c(length(nmachine), 8, S)), c(1,2), sd)

AMS <- Reduce("+",ms)/length(ms)
AMSSD <- apply(array(unlist(ms), c(length(nmachine), 8, S)), c(1,2), sd)

ACF <- Reduce("+",cf)/length(cf)
ACFSD <- apply(array(unlist(ms), c(length(nmachine), 8, S)), c(1,2), sd)

ACT<- Reduce("+",ct)/length(ct)
ACTSD <- apply(array(unlist(ct), c(length(nmachine), 3, S)), c(1,2), sd)
  
AEE
AEESD
AMS
AMSSD
ACF
ACFSD
ACT
ACTSD
  