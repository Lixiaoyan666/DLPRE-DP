
library(ggplot2)
library(ggpubr)
library(RColorBrewer)  
library(Runuran)
library(matrixStats)
library(doParallel) 
library(doSNOW)
library(foreach)
library(glmnet)
library(dfoptim)  # derivative-free optimization 
library(ggforce)
library(parallel)
library(MASS)



#global least product relative error estimator
glpre <- function(x, y, w){
  x <- as.matrix(x)
  y <- as.vector(y)
  n <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  t1 <- proc.time()
  par <- coef(lm(log(y)~x+0))
  t2 <- proc.time()
  b.est <- par+100 
  for(k in 1:1000){
    f <- tx %*% ((yinv * exp(x %*% par) - y*exp(-x %*% par))*w) 
    tt <- (yinv*exp(x %*% par)+y*exp(-x %*% par))*w 
    f_diff=tx %*% (x*c(tt)) 
    b.est <- par-solve(f_diff)%*%f
    if(norm(b.est - par,"2")<=1e-6) break
    par <- b.est
  }
  t3 <- proc.time()
  return(list(beta=b.est,ct=(t3-t1)[3]))
}

#penalized global least product relative error estimator
gplpre <- function(x, y, lambda=NULL, gamma=1){
  N <- length(y)
  p <- ncol(x)
  t1 <- proc.time()
  beta.glpre <- glpre(x, y,1)$beta
  if(all(x[,1]==1)){ 
    intercept <- TRUE
    x <- x[, -1]
    beta.glpre <- beta.glpre[-1]
  }else{
    intercept <- FALSE
  }
  if(is.null(lambda)){
    lambda_max <- max(abs(t(x) %*% log(y))/N)
    lambda_min <- lambda_max * 1e-3
    lambda1 <- seq(log(lambda_max), log(lambda_min), length=50)
    lambda <- exp(lambda1)
  }
  
  w <- 1/abs(1/N+abs(beta.glpre))^gamma 
  fit <- lpre.admm(x, y, lambda=lambda, intercept=intercept, 
                   normalize=FALSE, gamma = gamma, penalty.factor=w) 
  xx <- as.matrix(cbind(1, x))
  y <- as.vector(y)
  dbic <- log(colMeans((y - exp(xx%*%fit$beta))^2/(y*exp(xx%*%fit$beta)))) + fit$df*log(N)/N
  if(intercept){
    beta <- fit$beta
  }else{
    beta <- fit$beta[-1, ]
  }
  t2 <- proc.time()
  return(list(beta=beta, df=fit$df, lambda=fit$lambda, dbic=dbic,ct=(t2-t1)[3]))
}


#ADMM algorithm for pglpre
lpre.admm <- function(x, y, lambda=NULL, intercept=FALSE, normalize=FALSE, 
                      gamma=0, penalty.factor=rep(1, ncol(x))){
  x <- as.matrix(x)
  y <- as.matrix(y)
  np <- dim(x)
  n <- np[1]
  p <- np[2]
  
  if(intercept){
    meanx <- colMeans(x)
    mprody <- max(abs(y))*prod(y/max(abs(y)))^(1/n) 
  }else{
    meanx <- rep(0, p)
    mprody <- 1
  }
  x <- scale(x, meanx, FALSE) 
  if(normalize){normx <- sqrt(colSums(x^2)) }else{ normx <- rep(1, p)}
  x <- scale(x, FALSE, normx)
  y <- y/mprody 
  tx <- t(x)
  
  if(is.null(lambda)) {
    lambda_max<-max(abs(tx%*%log(y))/n)
    lambda_min<-lambda_max * 1e-3
    lambda1<-seq(log(lambda_max), log(lambda_min), length=50)
    lambda<-exp(lambda1)
  } 
  
  solvelpre <- function(a, b, u, rho){
    D1 <- tx %*% (1/y*exp(x %*% b) - y*exp(-x %*% b))/n 
    tt <- 1/y*exp(x %*% b) + y*exp(-x %*% b)
    D2 <- tx %*% ( x*c(tt))/n  
    D.inverse <- solve(D2+diag(rho, p))
    q <- rho * a - u + D2 %*% b - D1
    beta <- D.inverse %*% q
    return(beta)
  }
  
  
  ##solve penlity lpre function 
  penlpre <- function(lambdaj){
    rho <- 1#; alpha <- 1.8
    ak <- bk <- uk <- rep(0,p)
    w <- lambdaj*penalty.factor^gamma
    if(n > p) bk <- lm(log(y) ~ x + 0)$coef 
    maxiter <- 300
    eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
    for (k in 1 : maxiter) {
      bnew <- solvelpre(ak, bk, uk, rho)
      #bnew <- alpha * bnew + (1 - alpha) * ak
      s <- bnew + uk/rho
      anew <- sign(s)*pmax(abs(s)-w/rho, 0)
      unew <- uk + rho * (bnew -anew)   
      
      if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
         norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
      #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
      
      bk <- bnew
      ak <- anew
      uk <- unew
    }
    return(c(k, length(which(anew!=0)), anew))
  }
  
  para <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
  iter <- para[1, ]
  df <- para[2, ]
  b <- scale(t(para[-c(1,2), ]), FALSE, normx)
  esti <- rbind(log(mprody) - meanx %*% t(b), t(b))
  
  return(list(beta=esti, lambda=lambda, df=df, iter=iter))
}

ls.admm <- function(x, y, lambda=NULL, intercept=FALSE, normalize=FALSE, 
                    gamma=0, penalty.factor=rep(1, ncol(x))){
  x <- as.matrix(x)
  y <- as.matrix(y)
  np <- dim(x)
  n <- np[1]
  p <- np[2]
  
  #��x��y�������Ļ�ȥ���ؾ���:y=exp(beta_0+X%*%beta)epsilon,
  if(intercept){
    meanx <- colMeans(x)
    meany <- mean(y)
  }else{
    meanx <- rep(0, p)
    meany <- 0
  }
  x <- scale(x, meanx, FALSE) #��x�������Ļ���scale�����ǽ�x�е�ÿһ�п�����һ���������ݣ�Ȼ�������б�׼����
  if(normalize){normx <- sqrt(colSums(x^2)) }else{ normx <- rep(1, p)}#ʵ������ͨ����Ҫ���б�׼��
  x <- scale(x, FALSE, normx)
  y <- y-meany #��y���Ļ�:y-mean(y)
  tx <- t(x)
  
  if(is.null(lambda)) {
    lambda_max<-max(abs(tx%*%y)/n)
    lambda_min<-lambda_max * 1e-3
    lambda1<-seq(log(lambda_max), log(lambda_min), length=50)
    lambda<-exp(lambda1)
  } 
  
  #Approximation algorithm to solve beta (SQP)
  solvelpre <- function(a, b, u, rho){
    D1 <- -tx %*% (y - x %*% b)/n #һ�׵�
    D2 <- tx %*% x/n  #���׵�������3����ʡʱ
    # SVD <- svd(D2+diag(rho, p))
    # D.inverse <- SVD$v%*%diag(1/SVD$d)%*%t(SVD$u)
    D.inverse <- solve(D2+diag(rho, p))
    q <- rho * a - u + D2 %*% b - D1
    beta <- D.inverse %*% q
    return(beta)
  }
  
  
  ##solve penlity lpre function 
  penlpre <- function(lambdaj){
    rho <- 1#; alpha <- 1.8
    ak <- bk <- uk <- rep(0,p)
    w <- lambdaj*penalty.factor^gamma
    if(n > p) bk <- lm(y ~ x + 0)$coef 
    maxiter <- 300
    eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
    for (k in 1 : maxiter) {
      bnew <- solvelpre(ak, bk, uk, rho)
      #bnew <- alpha * bnew + (1 - alpha) * ak
      s <- bnew + uk/rho
      anew <- sign(s)*pmax(abs(s)-w/rho, 0)
      unew <- uk + rho * (bnew -anew)   
      
      if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
         norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
      #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
      
      bk <- bnew
      ak <- anew
      uk <- unew
    }
    return(c(k, length(which(anew!=0)), anew))
  }
  
  para <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
  iter <- para[1, ]
  df <- para[2, ]
  b <- scale(t(para[-c(1,2), ]), FALSE, normx)
  esti <- rbind(meany - meanx %*% t(b), t(b))
  
  return(list(beta=esti, lambda=lambda, df=df, iter=iter))
}

lpre_u <- function(x, y,r,nmachine){
  ##Method 2
  #x=X;y=Y;r0=n
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ## define the random pilot sample
  #q=0.1
  #a = q*N/nmachine
  #pilot_index = as.vector(sapply(1:nmachine, function(j){sample(groups[[j]],a)}))#sapply�Ľ��Ϊһ������
  t1 <- proc.time()
  index <- 1:N
  pi <- rep((r/N),N)
  decision <- rbinom(N,rep(1,N),prob=pi)#rbinom(n, size, prob)����n��b(size, prob)�Ķ���ֲ������
  pilot_index <- index[decision==1]
  t2 <- proc.time()
  t_p = (t2[3]-t1[3])/nmachine
  
  t.start <- proc.time()
  
  xu <- x[pilot_index, ]
  yu <- y[pilot_index]
  
  
  ## Calculate the initial estimate on pilot sample
  fit.glpre.u = glpre(xu,yu,1)
  beta = fit.glpre.u$beta
  #t_beta = fit.glpre.u$ct
  t.end <- proc.time()
  
  ct <- (t.end-t.start)[3] + t_p
  
  return(list(beta=beta, ct=ct,xu=xu,yu=yu))
}

lpre_p <- function(x, y, r0, r,tau,nmachine,alpha.case){
  ##Method 2
  #x=X;y=Y;r0;r=1000;tau = 0.1
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  p <- ncol(x)
  
  if(alpha.case==1){
    alpha <- diag(rep(1,p))
  }else{
    if(alpha.case==2){
      alpha <- rep(1,p)
    }else{
      alpha <- c(1,rep(0,p-1))  #rep(1/p,p)
    }
  } 
  
  ## get the pilot estimator and pilot sample
  fit.lpre.u = lpre_u(x, y, r0,nmachine)
  par0 = fit.lpre.u$beta
  t_u = fit.lpre.u$ct
  xu = fit.lpre.u$xu
  yu = fit.lpre.u$yu
  
  
  ## Calculate the subsampling probability and get the subsample
  t1 <- proc.time()
  epsilon.u = yu*exp(-xu %*% par0)
  D <- t(xu)%*%(xu*c(epsilon.u^{-1}+epsilon.u))/length(yu)  #������Ϣ����D_N_hat
  phi_hat <- sum(abs(epsilon.u^{-1} -epsilon.u)* (colSums((alpha %*%solve(D) %*% t(xu))^2))^{1/2})/length(yu)
  t2 <- proc.time()
  epsilon = y*exp(-x %*% par0)
  h <- abs(epsilon^{-1} - epsilon)* (colSums((alpha %*%solve(D) %*% t(x))^2))^{1/2}
  #phi_hat <- sum(abs(yinvu * exp(xu %*% par0) - yu*exp(-xu %*% par0))* ((rowSums(xu^2))^(1/2)))/length(yu)
  P <- h/(N*phi_hat)
  P.new <- abs((1-tau)*P+tau/N+1/(r+1e-6))/2-abs((1-tau)*P+tau/N-1/(r+1e-6))/2#ȡPi^1
  index <- 1:N
  eta <- rbinom(N,rep(1,N),prob=r*P.new)#rbinom(n, size, prob)����n��b(size, prob)�Ķ���ֲ������
  sub_index <- index[eta==1]
  #w <- 1/Pi
  t3 <- proc.time()
  t_p = (t3-t2)[3]/nmachine + (t2-t1)[3]
  
  t.start <- proc.time()
  
  ## Calculate the subsample estimator
  Pi.u <- rep(1/N,length(yu))# ע������ӳ�������Ϊ1/N
  
  xp <- x[sub_index, ]
  yp <- y[sub_index]
  Pi.p <- P.new[sub_index]
  
  xz=rbind(xu,xp) #��r0��r��Ϻ��x
  yz=c(yu,yp)
  Pi.z=(r+r0)*c(Pi.u,Pi.p)
  wz=1/Pi.z
  
  fit.lpre.p = glpre(xz,yz,wz)
  beta = fit.lpre.p$beta
  t.end <- proc.time()
  
  ct <- (t.end-t.start)[3] + t_p +t_u 
  
  return(list(beta=beta,ct=ct,wz=wz,xz=xz,yz=yz) )
}

plpre_p <- function(x, y, r0,r,tau,nmachine=2,lambda=NULL, gamma=1,alpha.case){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  
  lpre.p.admm <- function(xp, yp, wp,lambda=NULL, intercept=FALSE, normalize=FALSE, 
                          gamma=0, penalty.factor=rep(1, ncol(xp))){
    xp <- as.matrix(xp)
    yp <- as.matrix(yp)
    np <- dim(xp)
    n <- np[1]
    p <- np[2]
    
    if(intercept){
      meanxp <- colMeans(xp)
      mprodyp <- max(abs(yp))*prod(yp/max(abs(yp)))^(1/n) 
    }else{
      meanxp <- rep(0, p)
      mprodyp <- 1
    }
    xp <- scale(xp, meanxp, FALSE) 
    if(normalize){normxp <- sqrt(colSums(xp^2)) }else{ normxp <- rep(1, p)}
    xp <- scale(xp, FALSE, normxp)
    yp <- yp/mprodyp 
    txp <- t(xp)
    
    if(is.null(lambda)) {
      lambda_max<-max(abs(txp%*%log(yp))/n)
      lambda_min<-lambda_max * 1e-3
      lambda1<-seq(log(lambda_max), log(lambda_min), length=50)
      lambda<-exp(lambda1)
    } 
    
    #Approximation algorithm to solve beta (SQP)
    solvelpre <- function(a, b, u, rho){
      D1 <- txp %*% ((1/yp*exp(xp %*% b) - yp*exp(-xp %*% b))*wp/N)
      tt <- (1/yp*exp(xp %*% b) + yp*exp(-xp %*% b))*wp/N
      D2 <- txp %*% ( xp*c(tt))
      D.inverse <- solve(D2+diag(rho, p))
      q <- rho * a - u + D2 %*% b - D1
      beta <- D.inverse %*% q
      return(beta)
    }
    
    
    ##solve penlity lpre function 
    penlpre <- function(lambdaj){
      rho <- 1#; alpha <- 1.8
      ak <- bk <- uk <- rep(0,p)
      w <- lambdaj*penalty.factor^gamma
      if(n > p) bk <- lm(log(yp) ~ xp + 0)$coef 
      maxiter <- 300
      eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
      for (k in 1 : maxiter) {
        bnew <- solvelpre(ak, bk, uk, rho)
        #bnew <- alpha * bnew + (1 - alpha) * ak
        s <- bnew + uk/rho
        anew <- sign(s)*pmax(abs(s)-w/rho, 0)
        unew <- uk + rho * (bnew -anew)   
        
        if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
           norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
        #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
        
        bk <- bnew
        ak <- anew
        uk <- unew
      }
      return(c(k, length(which(anew!=0)), anew))
    }
    
    para <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
    iter <- para[1, ]
    df <- para[2, ]
    b <- scale(t(para[-c(1,2), ]), FALSE, normxp)
    esti <- rbind(log(mprodyp) - meanxp %*% t(b), t(b))
    
    return(list(beta=esti, lambda=lambda, df=df, iter=iter))
  }
  
  
  ## get the possion suasample and suasample estimator
  fit.lpre.p = lpre_p(x, y, r0,r,tau,nmachine,alpha.case)
  par = fit.lpre.p$beta
  t_p = fit.lpre.p$ct
  xp = fit.lpre.p$xz
  yp = fit.lpre.p$yz
  wp = fit.lpre.p$wz
  
  t1 <- proc.time()
  if(all(xp[,1]==1)){ 
    intercept <- TRUE
    xp <- xp[, -1]
    par <- par[-1]
  }else{
    intercept <- FALSE
  }
  if(is.null(lambda)){
    lambda_max <- max(abs(t(xp) %*% log(yp))/length(yp))
    lambda_min <- lambda_max * 1e-3
    lambda1 <- seq(log(lambda_max), log(lambda_min), length=50)
    lambda <- exp(lambda1)
  }
  
  w.penalty <- 1/abs(1/r+abs(par))^gamma 
  fit <- lpre.p.admm(xp, yp,wp, lambda=lambda, intercept=intercept, 
                     normalize=FALSE, gamma = gamma, penalty.factor=w.penalty) 
  xx <- as.matrix(cbind(1, xp))
  yp <- as.vector(yp)
  dbic <- log(colSums(((yp - exp(xx%*%fit$beta))^2/(yp*exp(xx%*%fit$beta)))*wp)/N) + fit$df*log(r)/r
  if(intercept){
    beta <- fit$beta
  }else{
    beta <- fit$beta[-1, ]
  }
  t2 <- proc.time()
  ct = t2[3]-t1[3] +t_p
  return(list(beta=beta, df=fit$df, lambda=fit$lambda, dbic=dbic,ct=ct))
}


dlpre_p <- function(x, y, r0,r,tau,nmachine=2, B=1,alpha.case,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- txj %*% ((yinv[groups[[j]]] * exp(x[groups[[j]], ] %*% par) 
                    - y[groups[[j]]]*exp(-x[groups[[j]], ] %*% par)))#
    fj
  }
  
  ## Calculate the gradient on subsample sample
  cd_p <- function(par){
    txp %*% ((yinvp * exp(xp %*% par) - yp*exp(-xp %*% par))*wp)/N 
  }
  
  ## get the possion suasample and subsample estimator
  fit.lpre.p = lpre_p(x, y, r0,r,tau,nmachine,alpha.case)
  par = fit.lpre.p$beta
  t_p = fit.lpre.p$ct
  xp = fit.lpre.p$xz
  yp = fit.lpre.p$yz
  wp = fit.lpre.p$wz
  
  t.start <- proc.time()
  
  txp = t(xp)
  yinvp = 1/yp
  
  time1 <- 0
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para)/n 
    cdp = cd_p(par)
    for (e in 1:1000) {
      fp <- cd_p(par) 
      dp <- (yinvp*exp(xp %*% par) + yp*exp(-xp %*% par))*wp
      f_diffp <-  txp %*% ( xp*c(dp)) 
      f_diffp = f_diffp/N
      b.est <- par - solve(f_diffp) %*% (fp - cdp + f)
      if(norm(b.est-par,"2") < 1e-6) break
      par <- b.est
    }
  }
  t.end <- proc.time()
  ct <- (t.end-t.start)[3] - (nmachine-1)*time1 +t_p
  return(list(beta=b.est,ct=ct,xp=xp,yp=yp,wp=wp))
}

dplpre_p <- function(x, y, r0,r,tau, nmachine=2,lambda=NULL, B=1, gamma=1,alpha.case,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- txj %*% (yinv[groups[[j]]] * exp(x[groups[[j]], ] %*% par) 
                   - y[groups[[j]]]*exp(-x[groups[[j]], ] %*% par)) 
    fj
  }
  
  ## Calculate the gradient on subsample sample
  cd_p <- function(par){
    txp %*% ((yinvp * exp(xp %*% par) - yp*exp(-xp %*% par))*wp)/N 
  }
  
  
  #Approximation algorithm to solve beta (SQP)
  solvelpre <- function(a, b, u, rho){
    fp <- cd_p(b)
    D1 <- fp - cdp + f
    tt <- (yinvp*exp(xp %*% b) + yp*exp(-xp %*% b))*wp
    D2 <- txp %*%  (xp*c(tt))
    D2 = D2/N
    D.inverse <- solve(D2+diag(rho, p))
    q <- rho * a - u + D2 %*% b - D1
    beta <- D.inverse %*% q
    return(beta)
  }
  
  ##solve penlity lpre function 
  penlpre <- function(lambdaj){
    rho <- 1#; alpha <- 1.8
    ak <- uk <- rep(0,p)
    bk <- par
    w <- lambdaj/(1/r + abs(par))^gamma
    if(all(x[, 1]==1)) {w[1] <- 0}
    maxiter <- 300
    eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
    for (k in 1 : maxiter) {
      bnew <- solvelpre(ak, bk, uk, rho)
      #bnew <- alpha * bnew + (1 - alpha) * ak
      s <- bnew + uk/rho
      anew <- sign(s)*pmax(abs(s)-w/rho, 0)
      unew <- uk + rho * (bnew -anew)   
      
      if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
         norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
      #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
      
      bk <- bnew
      ak <- anew
      uk <- unew
    }
    return(c(k, length(which(anew!=0)), anew))
  }
  
  
  ## get the possion suasample and suasample estimator as the initial estimate
  fit.lpre.p = lpre_p(x, y, r0,r,tau,nmachine,alpha.case)
  xp = fit.lpre.p$xz
  yp = fit.lpre.p$yz
  par = fit.lpre.p$beta
  t_p = fit.lpre.p$ct
  wp = fit.lpre.p$wz
  
  t.start <- proc.time()
  txp = t(xp)
  yinvp = 1/yp
  
  time1 <- 0
  if(length(lambda)!=1){B <- 1}
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para)/n 
    cdp <- cd_p(par) 
    res <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
    iter <- res[1, ]
    df <- res[2, ]
    beta <- res[-c(1,2), ]
    par <- beta
  }
  yp <- as.vector(yp)
  dbic <- log(colSums(((yp - exp(xp%*%beta))^2/(yp*exp(xp%*%beta)))*wp)/N-t(beta)%*%(cdp-f)
              +t(par)%*%(cdp-f)-colSums(((yp - exp(xp%*%par))^2/(yp*exp(xp%*%par)))*wp)/N
              +colMeans((y - exp(x%*%par))^2/(y*exp(x%*%par))))+df*log(N)/N
  t.end <- proc.time()
  ct <- (t.end-t.start)[3] -(nmachine-1)*time1  + t_p
  return(list(beta=beta, df=df, lambda=lambda, dbic=dbic,ct=ct,iter=iter))
}


#global least squares estimator
gls <- function(x, y,w){
  x <- as.matrix(x)
  y <- as.vector(y)
  t1 <- proc.time()
  b.est <- coef(lm(y~x+0,weights = w))#
  t2 <- proc.time()
  return(list(beta=b.est,ct=(t2-t1)[3]))
}

#penalized global least squares estimator(ADMM)
gpls <- function(x, y, lambda=NULL, gamma=1){
  N <- length(y)
  p <- ncol(x)
  beta.gls <- gls(x, y,rep(1,length(y)))$beta
  if(all(x[,1]==1)){ 
    intercept <- TRUE
    x <- x[, -1]
    beta.gls <- beta.gls[-1]
  }else{
    intercept <- FALSE
  }
  if(is.null(lambda)){
    lambda_max <- max(abs(t(x) %*% y)/N)
    lambda_min <- lambda_max * 1e-3
    lambda1 <- seq(log(lambda_max), log(lambda_min), length=50)
    lambda <- exp(lambda1)
  }
  w.penalty <- 1/abs(1/N+abs(beta.gls))^gamma
  fit <- ls.admm(x, y, lambda=lambda, intercept=intercept, 
                   normalize=FALSE, gamma = gamma, penalty.factor=w.penalty) 
  xx <- as.matrix(cbind(1, x))
  y <- as.vector(y)
  dbic <- log(colMeans((y - xx%*%fit$beta)^2)) + fit$df*log(N)/N
  if(intercept){
    beta <- fit$beta
  }else{
    beta <- fit$beta[-1, ]
  }
  return(list(beta=beta, df=fit$df, lambda=lambda, dbic=dbic))
}

ls_u <- function(x, y,r,nmachine){
  ##Method 2
  #x=X;y=Y;r0=n
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ## define the random pilot sample
  #q=0.1
  #a = q*N/nmachine
  #pilot_index = as.vector(sapply(1:nmachine, function(j){sample(groups[[j]],a)}))#sapply�Ľ��Ϊһ������
  t1 <- proc.time()
  index <- 1:N
  P  <- rep((1/N),N)
  decision <- rbinom(N,rep(1,N),prob=r*P)#rbinom(n, size, prob)����n��b(size, prob)�Ķ���ֲ������
  pilot_index <- index[decision==1]
  t2 <- proc.time()
  t_p = (t2[3]-t1[3])/nmachine
  
  xu <- x[pilot_index, ]
  yu <- y[pilot_index]
  txu <- tx[, pilot_index] 
  yinvu <- yinv[pilot_index]
  p.u <- P[pilot_index]
  wu <- 1/(r*p.u)
  
  ## Calculate the initial estimate on pilot sample
  fit.gls.u = gls(xu,yu,wu)
  beta = fit.gls.u$beta
  t_beta = fit.gls.u$ct
  ct <- t_p + t_beta
  
  return(list(beta=beta, ct=ct,xu=xu,yu=yu))
}

ls_p <- function(x, y, r0, r,tau,nmachine,alpha.case){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  p <- ncol(x)
  
  if(alpha.case==1){
    alpha <- diag(rep(1,p))
  }else{
    if(alpha.case==2){
      alpha <- rep(1,p)
    }else{
      alpha <- c(1,rep(0,p-1))  
    }
  } 
  
  ## get the pilot estimator and pilot sample
  fit.ls.u = ls_u(x, y, r0,nmachine)
  par0 = fit.ls.u$beta
  t_u = fit.ls.u$ct
  xu = fit.ls.u$xu
  yu = fit.ls.u$yu
  P.u <- rep(1/N,length(yu))
  txu = t(xu)
  yinvu = 1/yu
  
  ## Calculate the subsampling probability and get the subsample
  t1 <- proc.time()
  epsilon.u = yu-xu %*% par0
  D <- t(xu)%*% xu/length(yu)  
  phi_hat <- sum(abs(epsilon.u)* (colSums((alpha %*%solve(D) %*% t(xu))^2))^{1/2})/length(yu)
  t2 <- proc.time()
  epsilon = y-x %*% par0
  h <- abs( epsilon)* (colSums((alpha %*%solve(D) %*% t(x))^2))^{1/2}
  P <- h/(N*phi_hat)
  P.new <- abs((1-tau)*P+tau/N+1/(r+1e-6))/2-abs((1-tau)*P+tau/N-1/(r+1e-6))/2
  index <- 1:N
  eta <- rbinom(N,rep(1,N),prob=r*P.new)
  sub_index <- index[eta==1]
  t3 <- proc.time()
  t_p = (t3-t2)[3]/nmachine + (t2-t1)[3]
  
  ## Calculate the subsample estimator
  xp <- x[sub_index, ]
  yp <- y[sub_index]
  txp <- tx[, sub_index]
  yinvp <- yinv[sub_index]
  P.p <- P.new[sub_index]
  
  xz=rbind(xu,xp) 
  yz=c(yu,yp)
  P.z=(r+r0)*c(P.u,P.p)
  wz=1/P.z
  
  fit.ls.p = gls(xz,yz,wz)
  beta = fit.ls.p$beta
  t_beta = fit.ls.p$ct
  
  ct = t_u + t_p + t_beta
  
  return(list(beta=beta,ct=ct,wz=wz,xz=xz,yz=yz) )
}

pls_p <- function(x, y, r0, r,tau,nmachine,lambda=NULL, gamma=1,alpha.case){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  p <- ncol(x)

  ls.p.admm <- function(xp, yp,wp, lambda=NULL, intercept=FALSE, normalize=FALSE, 
                      gamma=0, penalty.factor=rep(1, ncol(xp))){
    xp <- as.matrix(xp)
    yp <- as.matrix(yp)
    np <- dim(xp)
    n <- np[1]
    p <- np[2]
    
    if(intercept){
      meanxp <- colMeans(xp)
      meanyp <- mean(yp)
    }else{
      meanxp <- rep(0, p)
      meanyp <- 0
    }
    xp <- scale(xp, meanxp, FALSE) 
    if(normalize){normxp <- sqrt(colSums(xp^2)) }else{ normxp <- rep(1, p)}
    xp <- scale(xp, FALSE, normxp)
    yp <- yp-meanyp 
    txp <- t(xp)
    
    if(is.null(lambda)) {
      lambda_max<-max(abs(txp%*%yp)/n)
      lambda_min<-lambda_max * 1e-3
      lambda1<-seq(log(lambda_max), log(lambda_min), length=50)
      lambda<-exp(lambda1)
    } 
    
    #Approximation algorithm to solve beta (SQP)
    solvelpre <- function(a, b, u, rho){
      D1 <- -txp %*% ((yp - xp %*% b)*wp/N) 
      D2 <- txp %*% (xp*wp/N)  
      D.inverse <- solve(D2+diag(rho, p))
      q <- rho * a - u + D2 %*% b - D1
      beta <- D.inverse %*% q
      return(beta)
    }
    
    
    ##solve penlity lpre function 
    penlpre <- function(lambdaj){
      rho <- 1#; alpha <- 1.8
      ak <- bk <- uk <- rep(0,p)
      w <- lambdaj*penalty.factor^gamma
      if(n > p) bk <- lm(yp ~ xp + 0)$coef 
      maxiter <- 300
      eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
      for (k in 1 : maxiter) {
        bnew <- solvelpre(ak, bk, uk, rho)
        #bnew <- alpha * bnew + (1 - alpha) * ak
        s <- bnew + uk/rho
        anew <- sign(s)*pmax(abs(s)-w/rho, 0)
        unew <- uk + rho * (bnew -anew)   
        
        if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
           norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
        #if(norm(bnew-ak,"2")<eps2&&norm(anew-ak,"2")<eps2) break
        
        bk <- bnew
        ak <- anew
        uk <- unew
      }
      return(c(k, length(which(anew!=0)), anew))
    }
    
    para <- sapply(1:length(lambda), function(j){penlpre(lambda[j])})
    iter <- para[1, ]
    df <- para[2, ]
    b <- scale(t(para[-c(1,2), ]), FALSE, normxp)
    esti <- rbind(meanyp - meanxp %*% t(b), t(b))
    
    return(list(beta=esti, lambda=lambda, df=df, iter=iter))
  }
  
  
  ## get the pilot estimator and pilot sample
  fit.ls.p = ls_p(x, y, r0, r,tau,nmachine,alpha.case)
  par = fit.ls.p$beta
  t_p = fit.ls.p$ct
  xp = fit.ls.p$xz
  yp = fit.ls.p$yz
  wp = fit.ls.p$wz
  
  t1 <- proc.time()
  
  if(all(xp[,1]==1)){ 
    intercept <- TRUE
    xp <- xp[, -1]
    par <- par[-1]
  }else{
    intercept <- FALSE
  }
  if(is.null(lambda)){
    lambda_max <- max(abs(t(x) %*% y)/N)
    lambda_min <- lambda_max * 1e-3
    lambda1 <- seq(log(lambda_max), log(lambda_min), length=50)
    lambda <- exp(lambda1)
  }
  w.penalty <- 1/abs(1/N+abs(par))^gamma
  fit <- ls.p.admm(xp, yp, wp,lambda=lambda, intercept=intercept, 
                 normalize=FALSE, gamma = gamma, penalty.factor=w.penalty) 
  xx <- as.matrix(cbind(1, xp))
  yp <- as.vector(yp)
  dbic <- log(colMeans((yp - xx%*%fit$beta)^2)) + fit$df*log(N)/N
  if(intercept){
    beta <- fit$beta
  }else{
    beta <- fit$beta[-1, ]
  }  
  t2 <- proc.time()
  ct = t2[3]-t1[3] +t_p
  return(list(beta=beta, df=fit$df, lambda=lambda, dbic=dbic,ct=ct))
}

#CSL estimator based on least squares loss
dls_p <- function(x, y, r0, r, tau,nmachine,alpha.case, B=1,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- -txj %*% (y[groups[[j]]] - x[groups[[j]], ] %*% par)  
    fj
  }
  
  ## Calculate the gradient on subsample sample
  cd_p <- function(par){
    txp %*% ((yp-xp%*%par)*wp)/N 
  }
  
  t.start <- proc.time()
  
  ## get the possion subsample and subsample estimator
  fit.ls.p = ls_p(x, y, r0,r,tau,nmachine,alpha.case)
  par = fit.ls.p$beta
  t_par = fit.ls.p$ct
  xp = fit.ls.p$xz
  yp = fit.ls.p$yz
  txp = t(xp)
  yinvp = 1/yp
  wp = fit.ls.p$wz
  
  time1 <- 0
  for (b in 1:B) {
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f1 <- cd(1)
    f <- rowMeans(para)/n
    f_diffp <-  txp %*% (xp*c(wp))/N
    b.est <- par - solve(f_diffp) %*% f 
    par <- b.est
  }
  t.end <- proc.time()
  running.time <- (t.end-t.start)[3] - (nmachine-1)*time1 - (nmachine-1)*t_par
  return(list(beta=b.est, ct=running.time))
}


#penalized CSL estimator based on least squares loss
dpls_p <- function(x, y, r0,r,tau, nmachine=2,lambda,B=1, gamma=1,alpha.case,dist.type){
  x <- as.matrix(x)
  y <- as.vector(y)
  N <- length(y)
  p <- ncol(x)
  tx <- t(x)
  yinv <- 1/y
  
  ##Define sample on each machine
  n <- trunc(N/nmachine)
  o1 <- 1:N
  o2 <- order(y)
  o3 <- order(x[,1])
  o = switch(dist.type, o1, o2, o3)
  groups <- vector("list", nmachine)
  for (j in 1:(nmachine - 1)) {
    jj <- (1 + (j - 1) * n)
    groups[[j]] <- (o[jj:(jj + n - 1)])
  }
  groups[[nmachine]] <- o[(1 + (nmachine - 1) * n):N]
  
  
  ## define function for sovlve gradient for each machine 
  cd <- function(j){
    txj <- tx[, groups[[j]]]
    fj <- -txj %*% (y[groups[[j]]] - x[groups[[j]], ] %*% par)  
    fj
  }
  
  
  ## Calculate the gradient on subsample sample
  cd_p <- function(par){
    txp %*% ((yp-xp%*%par)*wp)/N 
  }
 
  
  #Approximation algorithm to solve beta (SQP)
  solvels <- function(a, u, rho){
    D1 <- -txp %*% (yp*c(wp))/N - cdp + f
    D2 <- txp %*% (xp*c(wp))/N
    D.inverse <- solve(D2+diag(rho, p))
    q <- rho * a - u - D1
    beta <- D.inverse %*% q
    return(beta)
  }
  
  ##solve penlity lpre function 
  penls <- function(lambdaj){
    rho <- 1#; alpha <- 1.8
    ak <- par
    uk <- rep(0,p)
    w <- lambdaj/(1/r + abs(par))^gamma
    if(all(x[, 1]==1)){ w[1] <- 0}
    maxiter <- 300
    eps1 <- sqrt(p)*10^-4; eps2 <- 10^-2
    for (k in 1 : maxiter) {
      bnew <- solvels(ak, uk, rho)
      #bnew <- alpha * bnew + (1 - alpha) * ak
      s <- bnew + uk/rho
      anew <- sign(s)*pmax(abs(s)-w/rho, 0)
      unew <- uk + rho * (bnew -anew)   
      
      if(norm(bnew-anew,"2") < eps1+eps2*max(norm(bnew,"2"),norm(anew,"2")) &&
         norm(anew-ak,"2") < eps1/sqrt(rho)+eps2*norm(unew,"2")) break
      
      ak <- anew
      uk <- unew
    }
    return(c(k, length(which(anew!=0)), anew))
  }
  
  t.start <- proc.time()
  
  ## get the possion suasample and suasample estimator as the initial estimate
  fit.ls.p = ls_p(x, y, r0,r,tau,nmachine,alpha.case)
  xp = fit.ls.p$xz
  yp = fit.ls.p$yz
  txp = t(xp)
  yinvp = 1/yp
  par = fit.ls.p$beta
  t_par = fit.ls.p$ct
  wp = fit.ls.p$wz
  
  time1 <- 0
  if(length(lambda)!=1){B <- 1}
  for(b in 1:B){
    t2 <- proc.time()
    para <- sapply(1:nmachine, cd)
    t3 <- proc.time()
    time1 <- (t3-t2)[3]/nmachine + time1
    f <- rowMeans(para)/n 
    cdp <- cd_p(par) 
    res <- sapply(1:length(lambda), function(j){penls(lambda[j])})
    iter <- res[1, ]
    df <- res[2, ]
    beta <- res[-c(1,2), ]
    par <- beta
  }
  dbic <- log(colMeans(((yp - xp%*%beta)^2)*wp/N)-t(beta)%*%(cdp-f)
              +t(par)%*%(cdp-f)-colMeans(((yp - xp%*%par)^2)*wp/N)
              +colMeans((y - x%*%par)^2))+df*log(N)/N
  t.end <- proc.time()
  running.time <- (t.end-t.start)[3] -(nmachine-1)*time1 -(nmachine-1)*t_par
  return(list(beta=beta, df=df, lambda=lambda, dbic=dbic,ct=running.time))
}

AEE.plot.r <- function(aee, aeesd, xlabel, ylabel, xname, yname, title){
  method.names = c( "GLPRE","DLPRE-P", "DLPRE-U","DDLPRE", "ALPRE", "LPRE-P", "LPRE-U","LPRE-F")
  dat = data.frame(xlabel=1:length(xlabel), aee=as.vector(aee),
                   aeesd=as.vector(aeesd), Method=rep(method.names, each=length(xlabel)))
  dat$Method <-factor(dat$Method, levels = method.names)
  fig = ggplot(data=dat, aes(x=xlabel, y=aee, fill=Method, shape=Method, 
                             colour=Method, group= Method))+
    #geom_errorbar(aes(ymin=aee-aeesd, ymax=aee+aeesd), size=0.5, width=0.2)+
    geom_line(linetype=2,linewidth=0.6) + #linewidth=0.6
    scale_fill_brewer(palette = "Set1")+
    #scale_color_manual(values=c("red", "black","blue", "green", "orange"))+
    #scale_color_manual(values = c(2,1,3,4,5))+
    geom_point(size=2) + scale_shape_manual(values = c(15,16,17,18,0,1,2,5))+
    scale_x_discrete(limits = as.factor(xlabel))+ 
    theme_bw()+
    scale_y_log10()+
    xlab(xname) + ylab(yname)+
    labs(title  = title)+  
    theme(plot.caption=element_text(colour = "black", hjust=0.5))
  fig
}

#Non-sparse models  (parameter estimation)
DGPfunA <- function(N, rho, case, error.type){
  if(case==1){
    p = 20;beta = rep(c(1,1.5),p/2)
  }else{p=60;beta = rep(c(1,1.5),p/2)}
  
  xx =  matrix(rnorm(N*p), N, p)
  
  if(rho==0){
    X=xx
  }else{
    corrmat = toeplitz(rho^(0:(p-1)))
    cholmat = chol(corrmat)            #chol(A) = A'A
    X = xx %*% cholmat
  }
  
  lpdf1 = function(x){ -x-1/x-log(x)+2 }              
  gen1 = ars.new(logpdf=lpdf1, lb=0.0000001, ub=Inf)
  f = function(x){ (1/2)*x^2-(1/2)*0.25-log(x)+log(0.5) }
  epsilon = switch(error.type, ur(gen1, N), rlnorm(N), exp(runif(N, -2, 2)))
  Y = exp(X%*%beta)*epsilon
  return(list(Y=Y, X=X, beta=beta))
}

#Sparse models  (variable selection)
DGPfunB <- function(N, rho, case, error.type){
  if(case==1){
    p = 10; beta = c(2,1.5,1,0.8,0.5,rep(0,p-5))
  }else{p=60; beta = c(2,1.5,1,0.8,0.5,rep(0,p-5))}
  
  xx =  matrix(rnorm(N*p), N, p)
  
  if(rho==0){
    X=xx
  }else{
    corrmat = toeplitz(rho^(0:(p-1)))
    cholmat = chol(corrmat)            #chol(A) = A'A
    X = xx %*% cholmat
  }
  
  lpdf1 = function(x){ -x-1/x-log(x)+2 }              
  gen1 = ars.new(logpdf=lpdf1, lb=0.0000001, ub=Inf)
  f = function(x){ (1/2)*x^2-(1/2)*0.25-log(x)+log(0.5) }
  epsilon = switch(error.type, ur(gen1, N), rlnorm(N), exp(runif(N, -2, 2)))
  
  Y = exp(X%*%beta)*epsilon
  return(list(Y=Y, X=X, beta=beta))
}
