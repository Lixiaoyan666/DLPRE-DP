source("functions3.R")

N=100000#200000
rho=0.5
case=1 #2
S=500
r0=120
tau=0.5
error.type=1#2,3
alpha.case=1#2
dist.type=2#1

AEE = AEE_SD = AMS = AMS_SD = ACF = ACF_SD = vector("list", 3)  
nmachine = c( 200,100,50,25)

cores <- detectCores()-2
cl <- makeCluster(cores)
registerDoParallel(cl, cores=cores)
sim.res <- foreach(aa=1:S, .packages =c("matrixStats", "MASS", "glmnet","Runuran")) %dopar%
  {
    
    dat = DGPfunB(N, rho, case, error.type)
    x = dat$X
    y = dat$Y
    beta = dat$beta
    
    lambda_max<-max(abs(t(x)%*%log(y))/N)
    lambda_min<-lambda_max * 1e-3
    lambda1<-seq(log(lambda_max), log(lambda_min), length=50)
    lambda<-exp(lambda1)
    
    nmachine =   c( 200,100,50,25)
    
    fit_gplpre = gplpre(x, y, lambda=lambda,gamma=1)
    t_gplpre_1 = proc.time()
    gplpre_beta = fit_gplpre$beta[, which.min(fit_gplpre$dbic)]
    t_gplpre_2 = proc.time()
    ee_gplpre = rep(norm(gplpre_beta-beta, "2"),length(nmachine))
    ms_gplpre = rep(sum(gplpre_beta!=0),length(nmachine))
    poi = which(beta!=0)
    fp_gplpre = sum(gplpre_beta[-poi]!=0)/ sum(beta==0)
    fn_gplpre = sum(gplpre_beta[poi]==0)/ sum(beta!=0)
    cf_gplpre = rep((fp_gplpre+fn_gplpre==0),length(nmachine))  
    
    fit_gpls = gpls(x, log(y), lambda=lambda,gamma=1)
    gpls_beta = fit_gpls$beta[, which.min(fit_gpls$dbic)]
    ee_gpls = rep(norm(gpls_beta-beta, "2"),length(nmachine))
    ms_gpls = rep(sum(gpls_beta!=0),length(nmachine))
    poi = which(beta!=0)#beta!=0����ָ��
    fp_gpls = sum(gpls_beta[-poi]!=0)/ sum(beta==0)
    fn_gpls = sum(gpls_beta[poi]==0)/ sum(beta!=0)
    cf_gpls = rep((fp_gpls+fn_gpls==0),length(nmachine)) 
    
    ee_k = matrix(,length(nmachine),4)
    ms_k = matrix(,length(nmachine),4)
    fp_k = matrix(,length(nmachine),4)
    fn_k = matrix(,length(nmachine),4)
    cf_k = matrix(,length(nmachine),4)
    
    for(k in 1:length(nmachine)){
      
      n = N/nmachine[k]
      
      fit_dplpre_p = dplpre_p(x, y, r0,r=n-r0,tau, nmachine=nmachine[k],lambda=lambda,B=1, gamma=1,alpha.case,dist.type)
      dplpre_p_beta = fit_dplpre_p$beta[, which.min(fit_dplpre_p$dbic)]
      
      fit_dpls_p = dpls_p(x, log(y), r0,r=n-r0,tau, nmachine=nmachine[k],lambda=lambda,B=1, gamma=1,alpha.case,dist.type)
      dpls_p_beta = fit_dpls_p$beta[, which.min(fit_dplpre_p$dbic)]
      
      fit_plpre_p <- plpre_p(x, y,r0, r=n-r0,tau,nmachine=nmachine[k],lambda=lambda, gamma=1,alpha.case)
      plpre_p_beta = fit_plpre_p$beta[, which.min(fit_plpre_p$dbic)]
      
      fit_pls_p <- pls_p(x, log(y), r0, r=n-r0,tau,nmachine=nmachine[k],lambda=lambda, gamma=1,alpha.case)
      pls_p_beta = fit_pls_p$beta[, which.min(fit_pls_p$dbic)]
      
      ee_k[k,] = c(norm(dpls_p_beta-beta, "2"),norm(dplpre_p_beta-beta, "2"),
                   norm(pls_p_beta-beta, "2"),norm(plpre_p_beta-beta, "2"))
      
      ms_k[k,] = c(sum(dpls_p_beta!=0), sum(dplpre_p_beta!=0),
                   sum(pls_p_beta!=0), sum(plpre_p_beta!=0))
      
      poi = which(beta!=0)
      
      fp_k[k,] = c(sum(dpls_p_beta[-poi]!=0), sum(dplpre_p_beta[-poi]!=0),
                   sum(pls_p_beta[-poi]!=0),  sum(plpre_p_beta[-poi]!=0))/sum(beta==0)
      
      fn_k[k,] = c(sum(dpls_p_beta[poi]==0), sum(dplpre_p_beta[poi]==0),
                   sum(pls_p_beta[poi]==0),  sum(plpre_p_beta[poi]==0))/sum(beta!=0)#��������
      
      cf_k[k,] = (fp_k[k,] + fn_k[k,]==0)
      
    }
    ee = cbind(ee_gpls, ee_gplpre, ee_k)
    ms = cbind(ms_gpls, ms_gplpre,  ms_k)
    cf = cbind(cf_gpls, cf_gplpre,  cf_k)
    
    colnames(ee) = c( "GPLS","GPLPRE", "DPLS-P","DPLPRE-P","PLS-P","PLPRE-P")
    colnames(ms) = c( "GPLS","GPLPRE", "DPLS-P","DPLPRE-P","PLS-P","PLPRE-P")
    colnames(cf) = c( "GPLS","GPLPRE", "DPLS-P","DPLPRE-P","PLS-P","PLPRE-P")
    
    return(list(EE=ee, MS=ms, CF=cf))
  }
stopImplicitCluster()
stopCluster(cl)

ee <- ms <-  cf <- list()
for (s in 1:length(sim.res)) {
  ee[[s]] <- sim.res[[s]]$EE 
  ms[[s]] <- sim.res[[s]]$MS
  cf[[s]] <- sim.res[[s]]$CF
}
AEE <- Reduce("+",ee)/length(ee)
AEESD <- apply(array(unlist(ee), c(length(nmachine), 6, S)), c(1,2), sd)#���б��о����ÿ��Ԫ�����׼��,c(length(nmachine), 8, S)�õ�S��length(nmachine)*2�ľ���c(1,2)�����Ծ���Ԫ�أ��к��У�ִ�С�sd��

AMS <- Reduce("+",ms)/length(ms)
AMSSD <- apply(array(unlist(ms), c(length(nmachine), 6, S)), c(1,2), sd)

ACF<- Reduce("+",cf)/length(cf)
ACFSD <- apply(array(unlist(ms), c(length(nmachine), 6, S)), c(1,2), sd)

colnames(AEE) = c( "GPLS","GPLPRE", "DPLS-P","DPLPRE-P","PLS-P","PLPRE-P")
colnames(ACF) = c( "GPLS","GPLPRE", "DPLS-P","DPLPRE-P","PLS-P","PLPRE-P")
colnames(AMS) = c( "GPLS","GPLPRE", "DPLS-P","DPLPRE-P","PLS-P","PLPRE-P")

AEE
AEESD
AMS
AMSSD
ACF
ACFSD  
   
  