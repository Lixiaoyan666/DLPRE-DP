source("functions3.R")

N=100000#200000
rho=0.5
case=1 #2
S=500
r0=120
tau=0.5
error.type=1#2,3
alpha.case=1#2
dist.type=2#1

nmachine = c( 500,400,200,100,50,25)
AEE = AEESD = matrix(,length(nmachine),6)

for (k in 1:length(nmachine)) {
  cores <- detectCores()-2
  cl <- makeCluster(cores)
  registerDoParallel(cl, cores=cores)
  sim.res = foreach(i=1:S, .packages =c("matrixStats", "MASS", "glmnet","Runuran")) %dopar%
    {
      n = N/nmachine[k]
      
      Data = DGPfunA(N=N, rho=rho, case=case, error.type)
      x = Data$X
      y = Data$Y
      beta = Data$beta
      
      fit.lpre_p = lpre_p(x, y, r0, r=n-r0, tau,nmachine=nmachine[k],alpha.case)
      beta_lpre_p = fit.lpre_p$beta
      aee_lpre_p = norm(beta_lpre_p-beta, "2")
      
      fit.ls_p = ls_p(x, log(y), r0, r=n-r0, tau,nmachine=nmachine[k],alpha.case)
      beta_ls_p = fit.ls_p$beta
      aee_ls_p = norm(beta_ls_p-beta, "2")
      
      fit.dlpre_p = dlpre_p(x, y, r0, r=n-r0, tau,nmachine=nmachine[k],alpha.case, B=1,dist.type)
      beta_dlpre_p = fit.dlpre_p$beta
      aee_dlpre_p = norm(beta_dlpre_p-beta, "2")
      
      fit.dls_p = dls_p(x, y=log(y), r0, r=n-r0, tau,nmachine=nmachine[k],alpha.case, B=1,dist.type)
      beta_dls_p = fit.dls_p$beta
      aee_dls_p = norm(beta_dls_p-beta, "2")
      
      beta_gls = gls(x, y=log(y),rep(1,length(y)))$beta
      beta_glpre = glpre(x, y, 1)$beta
      
      aee_gls =norm(beta_gls-beta, "2")
      aee_glpre =norm(beta_glpre-beta, "2")
      
      aee=c(aee_gls,aee_glpre,aee_dls_p,aee_dlpre_p,aee_lpre_p,aee_ls_p)#�õ�һ��1*3������
      
      return(list(EE=aee))
    }    
  
  stopImplicitCluster()
  stopCluster(cl)
  ee <-  list()
  for (s in 1:length(sim.res)) {
    ee[[s]] <- sim.res[[s]]$EE
  }
  AEE[k,] = Reduce("+",ee)/length(ee)
  AEESD[k,] <- apply(array(unlist(ee), c(1,6, S)), c(1,2), sd)
}
colnames(AEE) = c( "GLS","GLPRE", "DLS-P", "DLPRE-P","LPRE-P","LS-P")

xname = "percentage of subsample"
xlabel = 1/nmachine
plot = AEE.plot.r(AEE, AEESD, xlabel, ylabel=AEE, xname, yname="AEE", title="error distribution d1")
AEE
AEESD



